package com.nucleus.calculator;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public CalculatorServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		int num1 = Integer.parseInt(request.getParameter("Number1"));
		int num2 = Integer.parseInt(request.getParameter("Number2"));
		String op =  request.getParameter("Addition");
			   op = request.getParameter("Substraction");
			   op = request.getParameter("Multiplication");
			   op = request.getParameter("Division");
		
		PrintWriter p = response.getWriter();
		int result;
		
		if(op.equals("Add"))
		{
			result = num1+num2;
			p.println(result);
			
		}
		if(op.equals("Subtract"))
		{
			result = num1-num2;
			p.println(result);
		}
		if(op.equals("Multiply"))
			{
				result = num1*num2;
				p.println(result);
			}
			if(op.equals("Divide"))
			{
				result = num1/num2;
				p.println(result);
			}
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
