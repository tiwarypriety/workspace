package com.nucleus.dao;

import com.nucleus.model.Role;
import com.nucleus.model.User;

public interface UserDaoI 
{
	public boolean login(User user);
	public boolean addUser(User user);
	public boolean role(User u,Role role);
	public boolean exists(String user);
}
