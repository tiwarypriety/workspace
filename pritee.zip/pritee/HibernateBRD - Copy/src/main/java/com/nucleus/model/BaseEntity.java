package com.nucleus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name= "baseentity")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class BaseEntity {

	@Id
	@Length(min=1,max=10,message="Length Should not be more than 10!")
	@NotEmpty(message = "Code should not be empty!")
	@Column(name = "customercode")
	private String code;
	
	@NotEmpty(message = "Name should not be empty!")
	@Column(name = "cname")
	private String name;
	
	@NotEmpty	(message = "Address should not be empty!")
	@Column(name = "caddress")
	private String address;
	@NotEmpty(message = "Email should not be empty!")
	@Email
	@Column(name = "cemail")
	private String email;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
