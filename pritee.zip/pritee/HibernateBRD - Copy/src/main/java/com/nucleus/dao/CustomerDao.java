package com.nucleus.dao;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.Customer;


@Repository
public class CustomerDao implements CustomerDaoI{
	
	@Autowired
    private SessionFactory sf;
		
		@Override
		@Transactional	
	public boolean addCustomer(Customer customer)
	{
			Date date = Calendar.getInstance().getTime();  
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");  
			String date1 = dateFormat.format(date);		
			customer.setCreatedDate(date1);
			
		 sf.getCurrentSession().save(customer);  		
			return true;		
			
	}
		@Transactional	
		public boolean deleteCustomer(Customer customer)
		{
			
		String code=  customer.getCode();

			/*	Query q = sf.getCurrentSession().createQuery("delete from Customer where customercode=:code1");
			q.setParameter("code1", code);
		
			int t=q.executeUpdate();
			System.out.println(t);*/
			
			Object a = sf.getCurrentSession().get(Customer.class,code);

			if(a!=null)
			{
			sf.getCurrentSession().delete(a);
			return true;
			}
			else
			return false;
	
			
		}
		@Transactional	
		public boolean updateCustomer(Customer c)
		{
		
				Date date = Calendar.getInstance().getTime();  
				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");  
				String date1 = dateFormat.format(date);		
				c.setModifiedDate(date1);
				try
				{
				sf.getCurrentSession().update(c);
				return true;
			
				}
				catch(Exception e)
				{
					System.out.println(e);
					return false;
				}

			
		}
		@Transactional	
		public Customer viewCustomer(Customer c)
		{
					String code=  c.getCode();
					Customer c1= (Customer) sf.getCurrentSession().get(Customer.class, code);
					
					
					return c1;
		}
		
		@Transactional	
		public List<Customer> viewAll() 
		{
			
			Query query=sf.getCurrentSession().createQuery("from Customer");
			List<Customer> list=query.list();
			return list;
			
		}
		
		public boolean exists(String code)
		{
	
			Object  a =sf.getCurrentSession().get(Customer.class, code) ;
				
				if(a!=null)
				{
					return true;
				}
				
			return false;
		}
		
}
