package com.nucleus.dao;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.Role;
import com.nucleus.model.User;

@Repository
public class UserDao implements UserDaoI 
{

	

	@Autowired
    private SessionFactory sf;

		@Override
		@Transactional
		public boolean addUser(User user) 
		{			
		 sf.getCurrentSession().save(user);		
			return true;		
			
		}

		@Override
		public boolean login(User user) {
			return false;
		}
		
		@Transactional
		public boolean role(User u,Role role)
		{
			System.out.println("dao"+u);
			System.out.println(role);
			
			 sf.getCurrentSession().save(role);	
			
			
			return true;
			
		}
		@Transactional
		public boolean exists(String user)
		{
			Object  a =sf.getCurrentSession().get(User.class, user) ;
			
			if(a!=null)
			{
				return true;
			}
			
			return false;
		
			
		}
}
