package com.nucleus.controller;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


public class PasswordEncoder {

	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	
public String encoder(String password)
{
	
			String hashedPassword = passwordEncoder.encode(password);
			System.out.println(hashedPassword);
			

		return hashedPassword;
}
	
}