package com.nucleus.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name = "user108")
public class User implements Serializable
{
@Id
@NotEmpty(message ="Username can't be empty!! ")
private String userId;
@NotEmpty(message ="Password Should not be empty!! ")
private String pass;
private int enabled;

@ManyToOne(cascade=CascadeType.ALL)
private Role role;

public Role getRole() {
	return role;
}
public void setRole(Role role) {
	this.role = role;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public int getEnabled() {
	return enabled;
}
public void setEnabled(int enabled) {
	this.enabled = enabled;
}
@Override
public String toString() {
	return "User [userId=" + userId + ", pass=" + pass + ", enabled=" + enabled + "]";
}

}
