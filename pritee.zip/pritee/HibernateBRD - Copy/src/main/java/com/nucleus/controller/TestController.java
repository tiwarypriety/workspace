package com.nucleus.controller;

import java.security.Principal;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.nucleus.model.Customer;
import com.nucleus.model.User;
import com.nucleus.service.CustomerServiceI;
import com.nucleus.service.UserServiceI;
import org.apache.log4j.Logger; 
import org.apache.log4j.PropertyConfigurator; 


@Controller
public class TestController 
{
	@Autowired
	UserServiceI service;
	@Autowired
	CustomerServiceI cs;
	/*@Autowired
	MessageSource ms;
	String s = ms.getMessage("a", null,"not Found",null);*/
	
	
	final static Logger logger=Logger.getLogger(com.nucleus.controller.TestController.class);
	
	@RequestMapping(value ="addpage",method= RequestMethod.GET)
	public ModelAndView  addpage(@ModelAttribute("customer") Customer customer)
	{
		
					 return new ModelAndView("AddCustomer"); 
		
	}
	@RequestMapping(value ="updatepage",method= RequestMethod.GET)
	public ModelAndView  updatepage(@ModelAttribute("customer") Customer customer)
	{
				//s	throw new ArithmeticException();
					return new ModelAndView("UpdateCustomer");
			
	}
	@RequestMapping(value ="deletepage",method= RequestMethod.GET)
	public ModelAndView  deletepage(@ModelAttribute("customer") Customer customer,Principal principal)
	{
			
					String username = principal.getName();		
					return new ModelAndView("DeleteCustomer","username",username);
				
	}
	@RequestMapping(value ="logout",method= RequestMethod.GET)
	public String  logout()
	{
			
					return "Logout";
				
	}
	@RequestMapping(value ="/viewpage",method= RequestMethod.GET)
	public ModelAndView  view(Principal principal)
	{
			
					String username = principal.getName();				
					return new ModelAndView("SingleCustomer","username",username);
				
	}

	@RequestMapping(value="/userpage", method= RequestMethod.GET)
	public ModelAndView userpage(Principal principal)
	{
					String username = principal.getName();
					return new ModelAndView("Home","username",username);
					
	}	

	@RequestMapping(value="/adminpage", method= RequestMethod.GET)
	public ModelAndView checker()
	{
					return new ModelAndView("Add");
				
	}
			
	@RequestMapping(value="/user", method= RequestMethod.GET)
	public ModelAndView user(@ModelAttribute("user") User user,Principal principal)
	{
			
					String username = principal.getName();		
					return new ModelAndView("AddUser","username",username);
				
	}

	@RequestMapping(value="/admin", method= RequestMethod.GET)
	public ModelAndView admin(@ModelAttribute("user") User user,Principal principal)
	{
			
					String username = principal.getName();		
					return new ModelAndView("AddAdmin","username",username);
	
	}
	@RequestMapping(value="/adduser", method= RequestMethod.POST)
	public ModelAndView adduser(@Valid @ModelAttribute("user") User user,BindingResult result,Principal principal)
	{
			ModelAndView view;
			try
			{
						
						logger.info("INSERTING USER");
						String username = principal.getName();		
						boolean exist = service.exists(user.getUserId());
						System.out.println(exist);
						if(!exist)
						{										 
										boolean res = service.addUser(user);
										if(res)
										{
											view=new ModelAndView("Add","message","User Added!!");
										}
										else
										{
										 view=new ModelAndView("failure","message","Something went Wrong!!");
										} 
										return view;
						}
						else
						{
							view=new ModelAndView("AddUser","message","Userid already Exist in database!!");
							return view;
						}
			}
			catch(Exception e)
			{
				logger.warn("Problem occured while INSERTING USER");
				logger.error(e.getMessage());
			}
			return new ModelAndView("AddUser","message","Some Error Occured!!");
			
		}
	@RequestMapping(value="/addadmin", method= RequestMethod.POST)
	public ModelAndView addadmin(@Valid @ModelAttribute("user") User user,BindingResult result,Principal principal)
	{
			ModelAndView view;
			try
			{
					logger.info("INSERTING ADMIN");
					PropertyConfigurator.configure("log4j.properties");
					if(result.hasErrors())
					{				
						return new ModelAndView("failure","message","Something went Wrong!!");
					}
					String username = principal.getName();		
					boolean exist = service.exists(user.getUserId());
					if(!exist)
					{
								
								boolean res = service.addAdmin(user);
								if(res)
								{
									view=new ModelAndView("Add","message","Admin Added!!");
								}
								else
								{
									view=new ModelAndView("failure","message","Something went Wrong!!");							
								} 
								return view;
					}
					else
					{
							view=new ModelAndView("AddAdmin","message","Userid already Exist in database!!");
							return view;
					}
			}
			catch(Exception e)
			{
				logger.warn("Problem occured while INSERTING ADMIN");
				logger.error(e.getMessage());
			}
			return new ModelAndView("AddAdmin","message","Some Error Occured!!");
	}
	@RequestMapping(value="insert", method= RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Principal p)
	{      			
		try
		{
					logger.info("INSERTING CUSTOMER");
					PropertyConfigurator.configure("log4j.properties");
					if(result.hasErrors())
					{				
						return new ModelAndView("AddCustomer","message","Something went Wrong!!");
					}
					boolean exist = cs.exists(customer.getCode());	
					if(!exist)
					{
					customer.setCreatedBy(p.getName());
					boolean res = cs.addCustomer(customer);
								if(res)
								{
									return	new ModelAndView("AddCustomer","message"," Record inserted in Database!!");
								}
								else
								{
									return	new ModelAndView("AddCustomer","message"," Record not inserted!!");
								}
					}
					else
					{
						return	new ModelAndView("AddCustomer","message"," code already exist in Database!!");
						
					}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING ADDING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView("AddCustomer","message","Some Error Occured!!");
			
	}
	@RequestMapping(value="delete", method= RequestMethod.POST)
	public ModelAndView deleteCustomer(@ModelAttribute("customer") Customer customer,Principal principal)
	{
		try
		{		
					logger.info("DELETING CUSTOMER");
					PropertyConfigurator.configure("log4j.properties");
					boolean exist = cs.exists(customer.getCode());
					boolean res;
					if(exist)
					{
							res = cs.deleteCustomer(customer);
					}
					else
					{
							return	new ModelAndView("DeleteCustomer","message"," Code Doesn't Exist  in database!!!");
					}
					if(res)
					{
							ModelAndView view=new ModelAndView("DeleteCustomer","message"," Record Deleted!!!");
							return view;
					}
					else
						
					{
							ModelAndView view=new ModelAndView("failure");
							return view;
					}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING DELETING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView("DeleteCustomer","message","Some Error Occured!!");
		
	}
	@RequestMapping(value ="update",method= RequestMethod.POST)
	public ModelAndView  update( @ModelAttribute("customer") Customer customer,Principal principal)
	{
		try
		{
						logger.info("UPDATING CUSTOMER");
						PropertyConfigurator.configure("log4j.properties");
						boolean exist = cs.exists(customer.getCode());
						if(exist)
						{
							
								Customer c = cs.viewCustomer(customer);
								return	new ModelAndView("Update","customer",c);	
						}
						else
						{
							return	new ModelAndView("UpdateCustomer","message"," Code Doesn't Exist  in database!!!");
						}
						
		
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING UPDATING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView("UpdateCustomer","message","Some Error Occured!!");
	
	}	
	@RequestMapping(value="updatecust", method= RequestMethod.POST)
	public ModelAndView updateCustomer(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Principal principal)
	{
		try
		{
			    logger.info("UPDATING CUSTOMER");
				PropertyConfigurator.configure("log4j.properties");
				if(result.hasErrors())
				{				
					return	new ModelAndView("failure");
				}
				else
				{
					boolean exist = cs.exists(customer.getCode());
					boolean res;
					if(exist)
					{
					 res = cs.updateCustomer(customer);
					}
					else
					{
						return	new ModelAndView("Update","message"," Code Doesn't Exist  in database!!!");
					}
					if(res)
					{
						ModelAndView view=new ModelAndView("UpdateCustomer","message"," Record Updated!!!");
						return view;
					}
					else
						
					{
						ModelAndView view=new ModelAndView("failure");
						return view;
					}
				
				}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING UPDATING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView("Update","message","Some Error Occured!!");
	
	}
	@RequestMapping(value="single", method= RequestMethod.POST)
	public ModelAndView viewCustomer(@ModelAttribute("customer") Customer customer)
	{
		
		try
		{	
			
						logger.info("VIEWING CUSTOMER DETAIL");
						PropertyConfigurator.configure("log4j.properties");
						boolean exist = cs.exists(customer.getCode());
						if(exist)
						{
							
							Customer c = cs.viewCustomer(customer);
							return	new ModelAndView("ViewCustomer","customer",c);	
						}
						else
						{
							return	new ModelAndView("SingleCustomer","message"," Code Doesn't Exist  in database!!!");
						}
					
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL");
			logger.error(e.getMessage());
		}
	
	return new ModelAndView("SingleCustomer","message","Some Error Occured!!");
	}
	@RequestMapping(value="viewall", method= RequestMethod.GET)
	public ModelAndView viewall(@ModelAttribute("customer") Customer customer,Principal principal)
	{
		

		try
		{	
					logger.info("VIEWING ALL CUSTOMER DETAIL");
					PropertyConfigurator.configure("log4j.properties");
					List<Customer> list = cs.viewAll();
					return	new ModelAndView("ViewAllDetails","cust",list);	
					
		
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL");
			logger.error(e.getMessage());
		}
	
	return new ModelAndView("ViewAllDetails","message","Some Error Occured!!");
		
	
	}
}
