package com.nucleus.datatable;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.LoginDAO;
import com.nucleus.dao.LoginDAOI;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ViewServlet() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Vendor v = new Vendor();
		LoginDAOI dao = new LoginDAO();
		ArrayList<Vendor> vendors = dao.view();
		request.setAttribute("vendors", vendors);
		System.out.println("Servlet");
		//System.out.println(vendors.get(1));
		for(int i=0;i<vendors.size();i++)
		{
						System.out.println(vendors.get(i));
		}
		System.out.println();
		RequestDispatcher rd=request.getRequestDispatcher("list.jsp");
		rd.forward(request, response);
	}

}
