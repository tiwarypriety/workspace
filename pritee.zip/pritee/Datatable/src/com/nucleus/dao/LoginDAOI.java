package com.nucleus.dao;

import java.util.ArrayList;

import com.nucleus.datatable.Vendor;

public interface LoginDAOI
{
	public boolean insertRecord(String u ,String p);
	public ArrayList<Vendor> view();
	
}
 