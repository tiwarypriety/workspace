package com.nucleus.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.nucleus.connection.ConnectionI;
import com.nucleus.connection.OracleConnection;
import com.nucleus.datatable.Vendor;
public class LoginDAO implements LoginDAOI
{
	
	Connection con  = null;
	ConnectionI ci = null;
	PreparedStatement pst = null ;
	ResultSet rs = null;
	public ArrayList<Vendor> view()
	{
		ArrayList<Vendor> vendors = new ArrayList<Vendor>();
	Vendor v = new Vendor();
		try
		{
			ci = new OracleConnection();
			con = ci.getConnection();
			
		String str = "select id,name from entry1909";		
		pst = con.prepareStatement(str);	
       rs = pst.executeQuery();
     while(rs.next())
     {
    	 System.out.println("RS : " +rs.getInt(1));
    	 v.setId(rs.getInt(1));
    	 v.setName(rs.getString(2));
        vendors.add(v);
     }  	

		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
System.out.println("Query executed"); 
//System.out.println(vendors.get(1).getId());
return vendors;
	}
	@Override
	public boolean insertRecord(String u, String p) {
		int rowsaffected = 0;
		try
		{
			if(con==null)
			{
			ci = new OracleConnection();
			con = ci.getConnection();
			}
			con.setAutoCommit(false);
			
		String str = "insert into Login1909 values(?,?) ";
		
		pst = con.prepareStatement(str);	
	
        pst.setString(1,u);
        pst.setString(2,p);
   
        rowsaffected = pst.executeUpdate();	  
        if(rowsaffected>0)
        {
        	System.out.println(rowsaffected);
        	return true;
        }
        else
        {
        	System.out.println(rowsaffected);
        	return false;
        }
		}
		catch(SQLException ex)
		{

			System.out.println("Record Already Exist in Database");
			return false;
		}
					
	
	}
	
	

	}
	


