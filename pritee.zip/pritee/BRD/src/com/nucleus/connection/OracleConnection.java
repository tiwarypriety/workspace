package com.nucleus.connection;

import java.io.FileReader;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.nucleus.connection.ConnectionI;

public class OracleConnection implements ConnectionI 
{

	Connection con = null;
	@Override
	public Connection getConnection()
	{
		try
		{		
			Properties prop = new Properties();

			FileReader fr = new FileReader("db.properties");
			prop.load(fr);
         
            String url = prop.getProperty("url");
            String user = prop.getProperty("user");
            String password = prop.getProperty("password");
            
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Established!!");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

}
