package com.day4_2;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Customer1909")
public class Customer extends User
{
private String address;

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}
}
