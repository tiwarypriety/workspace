package com.day4_2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Session session1=factory.openSession();
		Transaction t=session.beginTransaction();
		Customer c=new Customer();
		 c.setAddress("bhopal");
		 c.setUserId(1);
		 c.setUserName("ash");
		 session.save(c);
		 
		 /*Customer c2=new Customer();
		 c2.setAddress("bhopal");
		 c2.setUserId(1);
		 c2.setUserName("ash");
		
		 session.save(c2);*/
		 t.commit();
		 session.close();
	}
}
