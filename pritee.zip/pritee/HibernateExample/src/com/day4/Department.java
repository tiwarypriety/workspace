package com.day4;

import javax.persistence.Embeddable;

@Embeddable
public class Department {

private	int dNo;
private String dName;
public int getdNo() {
	return dNo;
}
public void setdNo(int dNo) {
	this.dNo = dNo;
}
public String getdName() {
	return dName;
}
public void setdName(String dName) {
	this.dName = dName;
}
	
}
