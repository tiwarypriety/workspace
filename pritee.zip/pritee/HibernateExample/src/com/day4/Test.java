package com.day4;



import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration c= new Configuration();
		c.configure();
		SessionFactory s = c.buildSessionFactory();
		Session session = s.openSession();
		Transaction t = session.beginTransaction();
		
		
		System.out.println("Enter your choice : ");
		System.out.println("1 : Save");
		System.out.println("2 : viewall");
		System.out.println("3 : view specific by Id");
		System.out.println("4 : where condition");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		switch(n)
		{
		case 1: 
			Address a = new Address();
			a.setCity("noida");
			a.setState("UP");
			
			Address a1 = new Address();
			a1.setCity("bhopal");
			a1.setState("MP");
			
			Department d = new Department();
			d.setdName("devlopment");
			d.setdNo(1);
			
			Employee e = new Employee();
			e.setName("ash");
			e.setSalary(2000);
			e.setDesignation("devloper");
			e.setDept(d);
			e.getAddres().add(a);
			session.save(e);
			t.commit();
			
			session.close();
			break;
							
		case 2: 
			 
			Query q = session.createQuery("from Employee");
			List<Employee> list = q.list();
			for(Employee e1:list)
			{
			
				System.out.println(e1);
			}
			t.commit();
			session.close();
			break;
			
		case 3:
			Query q1 = session.createQuery("from Employee where id = 3");
			Employee e2 = (Employee) q1.uniqueResult();
		
			/*Employee e2 =(Employee) session.get(Employee.class, 1);*/
			System.out.println(e2);
			t.commit();
			
			session.close();
			break;
		case 4:
			Query q2 = session.createQuery("from Employee where salary>1000");
			Employee e3 = (Employee) q2.uniqueResult();
			
		
			System.out.println(e3);
			t.commit();
			
			session.close();
			break;
			
		case 5:
			Query q3 = session.createQuery("");
			Employee e4 = (Employee) q3.uniqueResult();
			
		
			System.out.println(e4);
			t.commit();
			
			session.close();
			break;
			
			default : 
				System.out.println("done");
		}
		
		
		
		
		
	}

}
