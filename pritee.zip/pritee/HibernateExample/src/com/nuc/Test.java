package com.nuc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration c= new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory f=  c.buildSessionFactory();
		Session s = f.openSession();
		Transaction t = s.beginTransaction();
		Address a = new Address();
		a.setCity("noida");
		a.setState("UP");
		Vendor v = new Vendor();
		v.setvId(1);
		v.setvName("yash");
		v.setAdrs(a);
		s.save(v);
		t.commit();
		s.close();
	}

}
