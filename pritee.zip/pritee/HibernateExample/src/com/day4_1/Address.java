package com.day4_1;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity(name = "Adrs1909")
public class Address
{
			@Id
			@GeneratedValue(strategy=GenerationType.AUTO)
			private int aid;
			private String city;
			private String state;
			@ManyToOne(cascade=CascadeType.ALL)
			@JoinColumn(name = "Vendor")
			private Vendor v;
			public String getCity() {
				return city;
			}
			public void setCity(String city) {
				this.city = city;
			}
			public String getState() {
				return state;
			}
			public void setState(String state) {
				this.state = state;
			}
			@Override
			public String toString() {
				return "Address [city=" + city + ", state=" + state + "]";
			}
			public int getAid() {
				return aid;
			}
			public void setAid(int aid) {
				this.aid = aid;
			}
			public Vendor getV() {
				return v;
			}
			public void setV(Vendor v) {
				this.v = v;
			}

}
