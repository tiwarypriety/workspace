package com.day_3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@ Table(name ="vendor1909")
public class Vendor 
{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int vId;
private String vName;
/*@OneToOne(cascade=CascadeType.ALL)
private Address adrs;*/

/*@OneToMany(cascade=CascadeType.ALL)
private List<Address> adrs=new ArrayList<Address>();*/
public int getvId() {
	return vId;
}
public void setvId(int vId) {
	this.vId = vId;
}
public String getvName() {
	return vName;
}
public void setvName(String vName) {
	this.vName = vName;
}
/*public List<Address> getAdrs() {
	return adrs;
}
public void setAdrs(List<Address> adrs) {
	this.adrs = adrs;
}*/
/*public Address getAdrs() {
	return adrs;
}
public void setAdrs(Address adrs) {
	this.adrs = adrs;
}*/
}
