package com.day_3_1;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration c= new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory f=  c.buildSessionFactory();
		Session s = f.openSession();
		Transaction t = s.beginTransaction();
		
		
		Products p = new Products();
		p.setName("abc");
		Products p1 = new Products();
		p1.setName("xyz");
		Products p2 = new Products();
		p2.setName("abc");
		Products p3 = new Products();
		p3.setName("xyz");
		
		
		Stores st = new Stores();
		st.setsName("aaa");
		st.getproduct().add(p);
		st.getproduct().add(p1);
		Stores st1 = new Stores();
		st1.setsName("bbb");
		st1.getproduct().add(p);
		st1.getproduct().add(p1);
		s.save(st);	
		s.save(st1);	
		t.commit();
		s.close();
	}

}
