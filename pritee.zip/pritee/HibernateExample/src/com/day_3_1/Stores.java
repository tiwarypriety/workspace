package com.day_3_1;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@ Table(name ="store1909")
public class Stores 
{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int sId;
private String sName;

@ManyToMany(cascade=CascadeType.ALL)
private Set<Products> product=new HashSet<Products>();

public int getsId() {
	return sId;
}

public void setsId(int sId) {
	this.sId = sId;
}

public String getsName() {
	return sName;
}

public void setsName(String sName) {
	this.sName = sName;
}

public Set<Products> getproduct() {
	return product;
}

public void setproduct(Set<Products> product) {
	this.product = product;
}

}