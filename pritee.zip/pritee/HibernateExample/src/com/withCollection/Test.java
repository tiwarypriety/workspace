package com.withCollection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration c= new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory f=  c.buildSessionFactory();
		Session s = f.openSession();
		Transaction t = s.beginTransaction();
		Address a = new Address();                			//In this case it create two tables
		a.setCity("noida");
		a.setState("UP");
		Address a1 = new Address();
		a1.setCity("noida");						
		a1.setState("UP");
		Vendor v = new Vendor();
		v.setvName("yash");
		System.out.println(a);
		v.getAdrs().add(a);
		v.getAdrs().add(a1);		
		s.save(v);	
		t.commit();
		s.close();
	}

}
