package com.nucleus.service;

import com.nucleus.dao.LoginDAO;
import com.nucleus.dao.LoginDAOI;

public class Service {

	LoginDAOI dao = new LoginDAO();
	
 public boolean register(String user ,String pass)
 {

	boolean a = dao.insertRecord(user, pass);
	if(a)
	return true;
	return false;
 }
 public boolean login(String user ,String pass)
 {

	boolean a = dao.login(user, pass);
	if(a)
	return true;
	return false;
 }
 public boolean exists(String user)
 {
	boolean a =  dao.exists(user);
	if(a)
		return true;
		return false;
	 
 }
}