package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.nucleus.service.Service;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public SessionServlet() {
        super();
   
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(request.getServerPort());
		HttpSession session = request.getSession(false);
		System.out.println("Session = "+session);
		if(session!=null)
		{
			System.out.println("your session is not null");
		}
		else
		{
			System.out.println("session null");
		}
		
		String action = request.getParameter("action");
		System.out.println(action);
		PrintWriter p = response.getWriter();
	
		
	
		if (action.equals("Logout"))
			{
				if(session!=null)
				{
					RequestDispatcher  rd = request.getRequestDispatcher("Logout.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.include(request, response);
				}
			}
		else if (action.equals("Contact"))
		{
			if(session!=null)
			{
				RequestDispatcher  rd = request.getRequestDispatcher("Contact.jsp");
				rd.include(request, response);
			}
			else
			{
				RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
				rd.include(request, response);
			}
		}
		
}	
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		System.out.println("Session = "+session);
		if(session!=null)
		{
			System.out.println("your session is not null");
		}
		else
		{
			System.out.println("session null");
		}
		
		String action = request.getParameter("action");
		System.out.println(action);
		PrintWriter p = response.getWriter();
		if(action.equals("register"))
		{
		String user = request.getParameter("user1");
		String pass = request.getParameter("pass1");
		String cpass = request.getParameter("cPass");
			if(pass.equals(cpass))
			{
				Service s = new Service();
				boolean a = s.register(user, pass);
				
				if(a)
				{
					session = request.getSession();
					if(session!=null)
					{
						System.out.println("your session is not null");
					}
					else
					{
						System.out.println("session null");
					}
					p.println("Registration done!! Now You can Login");
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				}
				else					
				{
					p.println("Username Already Exist" );
					RequestDispatcher  rd = request.getRequestDispatcher("Home.jsp");
					rd.include(request, response);
				}
	
			}
			else
			{
				p.println("Password do not match");
				RequestDispatcher  rd = request.getRequestDispatcher("Register.jsp");
				rd.include(request, response);
			}
		}
		else if(action.equals("login"))
		{
			String user = request.getParameter("user");
			String pass = request.getParameter("pass");
			Service s = new Service();
			System.out.println(user);
			boolean exist = s.exists(user);
			System.out.println(exist);
			if(exist)
			{
				
			boolean a = s.login(user, pass);
			if(a)
			{
				session = request.getSession();
				System.out.println(session);
				if(session!=null)
				{
					System.out.println("your session is not null");
				}
				else
				{
					System.out.println("session null");
				}
				RequestDispatcher  rd = request.getRequestDispatcher("Home.jsp");
				rd.include(request, response);
			}
			else
			{
			p.print("username password do not match");
			RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
			rd.include(request, response);
			}
		
			}
			else
			{
				p.print("You are not a registered user!! Please register First!!");	
				RequestDispatcher  rd = request.getRequestDispatcher("Register.jsp");
				rd.include(request, response);
			}
		}
		else if (action.equals("logout"))
		{
			if(session!=null)
			{
				try
				{
			 session.invalidate();
			 
			 p.println("logged out Successully!!");
			
			 	RequestDispatcher  rd = request.getRequestDispatcher("Home.jsp");
				rd.include(request, response);
				}
				catch(Exception e)
				{
					RequestDispatcher  rd = request.getRequestDispatcher("ErrorPage.jsp");
					rd.include(request, response);
				}
			}
			else
			{

				RequestDispatcher  rd = request.getRequestDispatcher("LoginError.jsp");
				rd.forward(request, response);
				
			}
			if(session!=null)
			{
				
			}
			else
			{
				p.println("Session Expired!!");
				RequestDispatcher  rd = request.getRequestDispatcher("Home.jsp");
				rd.include(request, response);
			}		
		}
	}
}