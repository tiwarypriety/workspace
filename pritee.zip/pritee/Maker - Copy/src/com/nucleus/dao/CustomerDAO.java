package com.nucleus.dao;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.nucleus.connection.ConnectionI;
import com.nucleus.connection.OracleConnection;
import com.nucleus.entity.Customer;
public class CustomerDAO implements CustomerDAOI
{
	Connection con  = null;
	ConnectionI ci = null;
	PreparedStatement pst = null ;
	ResultSet rs = null;
	int rowsaffected = 0;
	@Override
	public boolean insert(Customer c)
	{
		int rowsaffected = 0;
		try
		{
			if(con==null)
			{
					ci = new OracleConnection();
					con = ci.getConnection();
			}
			
			con.setAutoCommit(false);			
		String str = "insert into customer_master19091 values(cus_id1909.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";		
		pst = con.prepareStatement(str);	
	
        pst.setString(1,c.getCode());
        pst.setString(2,c.getName());
        pst.setString(3,c.getAddress1());
        pst.setString(4,c.getAddress2());
        pst.setString(5,c.getPin());
        pst.setString(6,c.getEmail());
        pst.setString(7,c.getNumber());
        pst.setString(8,c.getContactPerson());
        pst.setString(9,c.getRecordStatus());
        pst.setString(10,c.getFlag());
        Date date = new Date();
        pst.setDate(11, new java.sql.Date(date.getTime()));
        pst.setString(12,c.getCreatedBy());
        pst.setDate(13, new java.sql.Date(date.getTime()));
        pst.setString(14,c.getModifiedBy());
        pst.setDate(15, new java.sql.Date(date.getTime()));
        pst.setString(16,c.getAuthorizedBy());  
      	
        rowsaffected = pst.executeUpdate();	     
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
		}
		finally
		{
			try
			{
				con.commit();
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
				if(rowsaffected>0)
				{
					return true;			
				}
				else
				{
					return false;
				}
	}

	public boolean exists(String code)
	{
		try
		{
			
				ci = new OracleConnection();
				con = ci.getConnection();
				String userCode = null;
			
		String str = "select code from customer_master19091 where code = ?";
		
		pst = con.prepareStatement(str);	
        pst.setString(1,code);
        rs = pst.executeQuery();
        	while(rs.next())
        	{
        			userCode = rs.getString(1);
        	}  	
        		if(code.equals(userCode))
        		{
        			return true;
        		}
        		else
        		{
        			return false;
        		}
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
				return false;
		}		
	}
	public boolean existsStatus(String status)
	{
		try
		{
				ci = new OracleConnection();
				con = ci.getConnection();
				String rStatus = null;
			
		String str = "select Record_status from customer_master19091 where Record_status = ?";
		
		pst = con.prepareStatement(str);	
        pst.setString(1,status);
        rs = pst.executeQuery();
        System.out.println(status);
        System.out.println(rs.next());
        	while(rs.next())
        	{
        			rStatus = rs.getString(1);
        			System.out.println("status = " +rStatus);
        	}  	
        		if(status.equals(rStatus))
        		{
        			return true;
        		}
        		else
        		{
        			return false;
        		}
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
				return false;
		}
		finally
		{
			try {
				con.commit();
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public ArrayList<Customer> viewCustomer(String code)
	{
		ArrayList<Customer> arr = new ArrayList<Customer>();
		try
		{			
				ci = new OracleConnection();
				con = ci.getConnection();

			String str = "select * from customer_master19091 where code=?";		
			pst = con.prepareStatement(str);	
			pst.setString(1,code);
			rs = pst.executeQuery();
       
			while(rs.next())
			{
				Customer c = new Customer();
				c.setCode(rs.getString(2));
				c.setName(rs.getString(3));
				c.setAddress1(rs.getString(4));
				c.setAddress2(rs.getString(5));    	 
				c.setPin(rs.getString(6));
				c.setEmail(rs.getString(7));
				c.setNumber(rs.getString(8));
				c.setContactPerson(rs.getString(9));
				c.setRecordStatus(rs.getString(10));
				c.setFlag(rs.getString(11));
				c.setModifiedDate();
				c.setCreatedBy(rs.getString(13));
				c.setModifiedDate();
		    	c.setModifiedBy(rs.getString(15));
		    	c.setAuthorizedDate();
		    	c.setAuthorizedBy(rs.getString(17));
		    	arr.add(c);
			}  	
		}
		catch(SQLException ex)
		{
			//System.out.println("Records already exist in database ");
			System.out.println(ex);
			 
		}
	  return arr;
	}
	public ArrayList<Customer> viewAllDetails()
	{
		ArrayList<Customer> a = new ArrayList<Customer>();
		
		try
		{
				ci = new OracleConnection();
				con = ci.getConnection();

			String str = "select * from customer_master19091 ";		
			pst = con.prepareStatement(str);	
			rs = pst.executeQuery();
			while(rs.next())
			{
    	   		Customer c = new Customer();
		       	 c.setCode(rs.getString(2));
		    	 c.setName(rs.getString(3));
		    	 c.setAddress1(rs.getString(4));
		    	 c.setAddress2(rs.getString(5));    	 
		    	 c.setPin(rs.getString(6));
		    	 c.setEmail(rs.getString(7));
		    	 c.setNumber(rs.getString(8));
		    	 c.setContactPerson(rs.getString(9));
		    	 c.setRecordStatus(rs.getString(10));
		    	 c.setFlag(rs.getString(11));
		    	 c.setCreatedDate();
		    	 c.setCreatedBy(rs.getString(13));
		    	 c.setModifiedDate();
		    	 c.setModifiedBy(rs.getString(15));
		    	 c.setAuthorizedDate();
		    	 c.setAuthorizedBy(rs.getString(17));   	 
		    	 a.add(c);    	
			}  		     
		}
		catch(Exception e)
		{
				System.out.println("view all detail dao ex");
		}
		return a;
	}
	public boolean delete(String code)
	{ 
		int a = 0;
		try
		{			
			ci = new OracleConnection();
			con = ci.getConnection();
			
		String str = "delete from customer_master19091 where code=?";
		
		pst = con.prepareStatement(str);	
        pst.setString(1,code);
        a = pst.executeUpdate();	
        	if(a>0)
        	{
        			return true;
        	}
        	else
        	{
        			return false;
        	}
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
				return false;
		}		
	}
	public boolean update(Customer c,String code)
	{ 
		int a = 0;
		try
		{
			ci = new OracleConnection();
			con = ci.getConnection();

		String str = "update customer_master19091 set name=?,address1 =?,address2=?,pin_code = ?,email = ?,contact_number=?,primary_contact_person= ?,record_status = ?,flag = ?,created_by=? , modified_date =?, modified_by =? where code = ?";
		
				pst = con.prepareStatement(str);
		        pst.setString(1,c.getName());
		        pst.setString(2,c.getAddress1());
		        pst.setString(3,c.getAddress2());
		        pst.setString(4,c.getPin());
		        pst.setString(5,c.getEmail());
		        pst.setString(6,c.getNumber());
		        pst.setString(7,c.getContactPerson());
		        pst.setString(8,c.getRecordStatus());
		        pst.setString(9,c.getFlag());
		        Date date = new Date();
		        pst.setString(10,c.getCreatedBy());
		        pst.setDate(11, new java.sql.Date(date.getTime()));
		        pst.setString(12, c.getModifiedBy());
		        pst.setString(13, c.getCode());
		 
		        a = pst.executeUpdate();				    
		        if(a>0)
		        {
		        	return true;
		        }
		        else
		        {
		        	return false;
		        }
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
				return false;
		}
		
	}
	public ArrayList<Customer> viewStatus(String status)
	{
		Customer c = new Customer();
		ArrayList<Customer> arr = new ArrayList<Customer>();
		try
		{			
				ci = new OracleConnection();
				con = ci.getConnection();

			String str = "select * from customer_master19091 where Record_Status=?";		
			pst = con.prepareStatement(str);	
			pst.setString(1,status);
			rs = pst.executeQuery();
       
			while(rs.next())
			{
				c.setCode(rs.getString(2));
				c.setName(rs.getString(3));
				c.setAddress1(rs.getString(4));
				c.setAddress2(rs.getString(5));    	 
				c.setPin(rs.getString(6));
				c.setEmail(rs.getString(7));
				c.setNumber(rs.getString(8));
				c.setContactPerson(rs.getString(9));
				c.setRecordStatus(rs.getString(10));
				c.setFlag(rs.getString(11));
				c.setModifiedDate();
				c.setCreatedBy(rs.getString(13));
				c.setModifiedDate();
		    	c.setModifiedBy(rs.getString(15));
		    	c.setAuthorizedDate();
		    	c.setAuthorizedBy(rs.getString(17));
		    	arr.add(c);
			}  	
		}
		catch(SQLException ex)
		{
				ex.printStackTrace();
		}
		return arr;
		
	}
}


