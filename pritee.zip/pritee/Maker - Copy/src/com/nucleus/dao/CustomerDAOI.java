package com.nucleus.dao;

import java.util.ArrayList;

import com.nucleus.entity.Customer;

public interface CustomerDAOI
{
	public boolean insert(Customer c);
	public boolean exists(String user);	
	public ArrayList<Customer> viewAllDetails();
	public boolean delete(String code);
	public boolean update(Customer c,String code);
	public ArrayList<Customer> viewCustomer(String code);
	public ArrayList<Customer> viewStatus(String status);
	 public boolean existsStatus(String status);

}
 