package com.nucleus.service;

public interface UserServiceI 
{
		public String getRole(String user);
		public boolean login(String user ,String pass);
}
