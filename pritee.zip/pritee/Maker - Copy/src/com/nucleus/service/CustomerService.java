package com.nucleus.service;

import java.util.ArrayList;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.dao.CustomerDAOI;
import com.nucleus.dao.UserDAO;
import com.nucleus.dao.UserDAOI;
import com.nucleus.entity.Customer;

public class CustomerService implements CustomerServiceI
{

	CustomerDAOI dao = new CustomerDAO();
	
 public boolean exists(String code)
 {
	 	boolean a =  dao.exists(code);
	 	if(a)
		return true;
		return false;	 
 }
 public boolean existsStatus(String status)
 {
	 	boolean a =  dao.existsStatus(status);
	 	if(a)
		return true;
		return false;	 
 }
 
 public ArrayList<Customer> viewCustomer(String code)
 {
	 	ArrayList<Customer> a = dao.viewCustomer(code);
	 	return a;	 
 }
	public ArrayList<Customer> viewAllDetails()
 {
		 ArrayList<Customer> a	= dao.viewAllDetails();
		 return a;	 
 }
	public boolean insert(Customer c)
	 {
			boolean a =  dao.insert(c);
			if(a)
			return true;
			return false;	 
	 }
	public boolean delete(String code)
	 {
			boolean a =  dao.delete(code);
			if(a)
			return true;
			return false;		 
	 }
	public boolean update(Customer c,String code)
	 {
			boolean a =  dao.update(c,code);
			if(a)
			return true;
			return false;		 
	 }
	public ArrayList<Customer> viewStatus(String status)
	 {
		 	ArrayList<Customer> a = dao.viewStatus(status);
		 	return a;	 
	 }
}