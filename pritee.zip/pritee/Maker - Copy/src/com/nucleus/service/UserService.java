package com.nucleus.service;

import com.nucleus.dao.UserDAO;
import com.nucleus.dao.UserDAOI;

public class UserService implements UserServiceI
{
	UserDAOI dao = new UserDAO();
	
	 public boolean login(String user ,String pass)
	 {
		 	boolean a = dao.login(user, pass);
		 	if(a)
		 	return true;
		 	return false;
	 }
	 public String getRole(String user)
	 {
		 	String role =  dao.getRole(user);
		 	return role;
		 
	 }
}
