package com.nucleus.service;

import java.util.ArrayList;

import com.nucleus.entity.Customer;

public interface CustomerServiceI 
{
	
		public boolean insert(Customer c);	
		public boolean exists(String user);	
		public boolean update(Customer c,String code);
		public boolean delete(String code);
		public ArrayList<Customer> viewCustomer(String code);
		public ArrayList<Customer> viewAllDetails();
		public ArrayList<Customer> viewStatus(String status);
		 public boolean existsStatus(String status);

}
