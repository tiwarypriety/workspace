package com.nucleus.controller;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
@WebFilter(urlPatterns = { "/UserServlet?action=login"})
public class TrimFilter implements Filter {

    public TrimFilter() {
        
    }
	
	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		String user = request.getParameter("user").trim();
		String password = request.getParameter("pass").trim();
		request.setAttribute("user", user);
		request.setAttribute("pass", password);
		chain.doFilter(request, response);
	}	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
