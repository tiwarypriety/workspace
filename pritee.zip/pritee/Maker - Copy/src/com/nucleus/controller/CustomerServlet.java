package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.nucleus.entity.Customer;
import com.nucleus.service.CustomerService;
import com.nucleus.service.CustomerServiceI;

@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CustomerServlet() {
        super();
     
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		String action = request.getParameter("action");
		HttpSession session = request.getSession(false);
		if (action.equals("Home"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("Home.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);				
			}	
		}
		else if (action.equals("AddCustomer"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("AddCustomer.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}

		else if (action.equals("Update"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("UpdateCustomer.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}
		else if (action.equals("Delete"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("DeleteCustomer.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}
		else  if (action.equals("SingleCustomer"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("SingleCustomer.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}
	 
		else  if (action.equals("AllCustomer"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("ViewAllCustomer.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}	
		else  if (action.equals("ViewByRecordStatus"))
		{
			if(session!=null)
			{
			
					RequestDispatcher  rd = request.getRequestDispatcher("RecordStatus.jsp");
					rd.include(request, response);
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				
			}	
		}	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Customer c = new Customer();
		PrintWriter p = response.getWriter();
		CustomerServiceI s = new CustomerService();
		HttpSession session = request.getSession(false);		
		String action = request.getParameter("action");
		
		
		if(action.equals("insert"))			
		{
			String code = request.getParameter("code");			
			String name = request.getParameter("name");
			String address1  =request.getParameter("address1");
			String address2  =request.getParameter("address2");
			String pin = request.getParameter("pin");
			String email = request.getParameter("email");
			String number = request.getParameter("number");
			String primaryContactPerson = request.getParameter("contactPerson");
			String createdBy = (String) session.getAttribute("username");
			
			c.setCode(code);
			c.setName(name);
			c.setAddress1(address1);
			c.setAddress2(address2);
			c.setPin(pin);
			c.setEmail(email);
			c.setNumber(number);
			c.setContactPerson(primaryContactPerson);
			c.setRecordStatus("N");
			c.setFlag("A");
			c.setCreatedDate();
			c.setCreatedBy(createdBy);
			
			boolean exist = s.exists(code);
			if(!exist)
			{
					boolean a = s.insert(c);
					if(a)				
					{
							p.println("Record inserted Successfully!!");
							RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
							rd.include(request, response);
					}
					else
					{
							p.println("Records Not inserted!!");
							RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
							rd.include(request, response);
					}
			}
			else
			{
					p.println("User Code Already Exist in Database!!");
					RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
					rd.include(request, response);
			}
			
		}	
		
		if(action.equals("update"))
		{
				String code = request.getParameter("code");
				boolean exist = s.exists(code);
				if(exist)
				{
					if(session!=null)
					{
							ArrayList<Customer> customer = s.viewCustomer(code);
							request.setAttribute("cus", customer);
							RequestDispatcher rd=request.getRequestDispatcher("Update.jsp");
							rd.include(request, response);
					}
					else
					{
							RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
					}
				}
				else
				{
					p.print("Record not Exist!!<br>");
					p.print("Enter a valid Customer Code!");
					RequestDispatcher  rd = request.getRequestDispatcher("UpdateCustomer.jsp");
					rd.include(request, response);
				}
		}
		
		if(action.equals("updateDetails"))
		{
			String code = request.getParameter("code");
			String name = request.getParameter("name");
			String address1  =request.getParameter("address1");
			String address2  =request.getParameter("address2");
			String pin = request.getParameter("pin");
			String email = request.getParameter("email");
			String number = request.getParameter("number");
			String primaryContactPerson = request.getParameter("contactPerson");
			String createdBy = (String) session.getAttribute("username");
			String modifiedBy = (String) session.getAttribute("username");
			
			c.setCode(code);
			c.setName(name);
			c.setAddress1(address1);
			c.setAddress2(address2);
			c.setPin(pin);
			c.setEmail(email);
			c.setNumber(number);
			c.setContactPerson(primaryContactPerson);
			c.setRecordStatus("M");
			c.setFlag("A");
			c.setCreatedDate();
			c.setCreatedBy(createdBy);
			c.setModifiedBy(modifiedBy);
			boolean a = s.update(c,code);
				if(a)
				{					
						p.println("Record updated Successfully!!");
						RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
						rd.include(request, response);

				}
				else
				{
						p.println("Record not updated!!");
						RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
						rd.include(request, response);
				}
		}
		
		if(action.equals("delete"))
		{
			String code = request.getParameter("code");
			boolean exist = s.exists(code);
			if(exist)
			{
					if(session!=null)
					{
							boolean a = s.delete(code);
							if(a)
							{
								p.println("Record deleted Successfully!!");
								RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
								rd.include(request, response);
							}
							else
							{
								p.println("Record Not deleted!!");
								RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
								rd.include(request, response);
							}
					}
					else
					{
							RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
					}
			}
			else
			{
				p.print("Record not Exist!!<br>");
				p.print("Enter a valid Customer Code!");
				RequestDispatcher  rd = request.getRequestDispatcher("DeleteCustomer.jsp");
				rd.include(request, response);
			}
		}
		
		
		if(action.equals("viewCustomer"))
		{
				String code = request.getParameter("code");
				boolean exist = s.exists(code);
				if(exist)
				{
					if(session!=null)
					{
							ArrayList<Customer> customer = s.viewCustomer(code);
							request.setAttribute("cust", customer);
							RequestDispatcher rd=request.getRequestDispatcher("ViewAllDetails.jsp");
							rd.include(request, response);
				
					}
					else
					{
							RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
					}
				}
				else
				{
					p.print("Record not Exist!!<br>");
					p.print("Enter a valid Customer Code!");
					RequestDispatcher  rd = request.getRequestDispatcher("SingleCustomer.jsp");
					rd.include(request, response);
				}
		}
		
		
		if(action.equals("viewAllCustomer"))
		{
			if(session!=null)
			{
					ArrayList<Customer> customer = s.viewAllDetails();
					request.setAttribute("cust", customer);
			
					RequestDispatcher rd=request.getRequestDispatcher("ViewAllDetails.jsp");
					rd.include(request, response);				
			}
			else
			{
					RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
					rd.include(request, response);
			}
		}
		if(action.equals("RecordStatus"))
		{
			String status = request.getParameter("status");
			boolean exist = s.existsStatus(status);
			if(exist)
			{
				if(session!=null)
				{
						ArrayList<Customer> customer = s.viewStatus(status);
						request.setAttribute("cust", customer);
						RequestDispatcher rd=request.getRequestDispatcher("ViewAllDetails.jsp");
						rd.include(request, response);				
				}
				else
				{
						RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
						rd.include(request, response);
				}			
			}
			else
			{
				p.print("Record not Exist!!<br>");
				p.print("Enter a valid Record Status!");
				RequestDispatcher  rd = request.getRequestDispatcher("RecordStatus.jsp");
				rd.include(request, response);
			}
		}
	}
}
