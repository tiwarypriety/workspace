package com.nucleus.entity;

import java.io.Serializable;
import java.util.Date;

public class Customer implements Serializable
{
	private String code;
	private String name;
	private String address1;
	private String address2;
	private String pin;
	private String email;
	private String number;
	private String contactPerson;
	private String recordStatus;
	private String flag;
	private Date createdDate;
	private String createdBy;
	private Date modifiedDate;
	private String modifiedBy;
	private Date authorizedDate;
	private String authorizedBy;
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate() {
		this.createdDate=new Date();
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate() {
		this.modifiedDate = new Date();
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getAuthorizedDate() {
		return authorizedDate;
	}
	public void setAuthorizedDate() {
		authorizedDate = new Date();
	}
	public String getAuthorizedBy() {
		return authorizedBy;
	}
	public void setAuthorizedBy(String str) {
		this.authorizedBy = str;
	}
	@Override
	public String toString() {
		return "Customer [code=" + code + ", name=" + name + ", address1=" + address1 + ", address2=" + address2
				+ ", pin=" + pin + ", email=" + email + ", number=" + number + ", contactPerson=" + contactPerson
				+ ", recordStatus=" + recordStatus + ", flag=" + flag + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy + ", authorizedDate="
				+ authorizedDate + ", authorizedBy=" + authorizedBy + "]";
	}
	
}
