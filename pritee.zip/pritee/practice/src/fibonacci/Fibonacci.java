package fibonacci;
import java.util.Scanner;

public class Fibonacci 
{
    public static int fib(int num)
	{
		 if(num==1||num==2)
		 {
			  return 1;
		 }
     return (fib(num-1)+fib(num-2));
    }

}
