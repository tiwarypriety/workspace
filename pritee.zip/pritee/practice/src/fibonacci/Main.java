package fibonacci;

import java.util.Scanner;

public class Main {

	public static void main(String[] args)
	{
		int num;
		double sum = 0;
		double avg = 0.0;
		System.out.println("Enter a number upto which you want to print fibonacii series");
		num = new Scanner(System.in).nextInt();;
		
		Fibonacci f = new Fibonacci();
		for(int i = 1;i<=num ;i++)
		{
			int fib = f.fib(i);
			System.out.print(fib+" ");
			
			sum = sum +fib;
			avg = sum/20;
	    }
		System.out.println();
		System.out.println("avg= "+avg);
	}

}
