package program3;

import java.util.*;

public class StudentGrades
{
	StudentGrades()
	{
		int numOfStudents;
		
		System.out.println("Enter number of students");
		Scanner sc = new Scanner(System.in);
		numOfStudents = sc.nextInt();
		int a[] = new int [numOfStudents];
		
		for(int i= 0;i<numOfStudents;i++)
		{
			System.out.println("Enter Grades for Student "+(i+1));
			int x = sc.nextInt();
				if(x>100&&x<0)
				{
					System.out.println("Invalid grade , try Again...");
					i--;
				}
			else
				a[i] = x;		
		}
		
		float avg = average(a,numOfStudents);
		System.out.println("Average = "+avg);
		
	}
	
		float average(int a[], int n)
		{
			int sum =0;
			for(int i =0;i<n;i++)
			{
				sum = sum + a[i];
			}
	      float average = sum/n;
		  return average;
		}
		
}

