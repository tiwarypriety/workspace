package program4;

public class Main {

	public static void main(String[] args) 
	{
		int a[] = new int[5];
		
			a[0] = 40;
			a[1] = 50;
			a[2] = 30;
			a[3] = 20;
			a[4] = 10;
			
		CopyArray c = new CopyArray(a);
	}

}
