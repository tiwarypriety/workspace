package program4;

public class CopyArray
{
	CopyArray(int a[])
	{		
		int b[] = copyOf(a);
		for(int i=0;i<b.length;i++)
		{
		System.out.println(b[i]);
		}
	}
	public static int[] copyOf(int[] array)
	{
		int b[] = new int[5];
		for(int i=0;i<array.length;i++)
		{
			b[i] = array[i];
	    }
		return b;
	}
}
