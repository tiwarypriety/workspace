package program2;

public class Main 
{
	public static void main(String[] args) 
	{
	MultiplicationTable m = new MultiplicationTable();

	}

}
