package program2;

public class MultiplicationTable 
{
	MultiplicationTable()
	{
		int i ,j;
	   
	     System.out.print("*|");
	     int x=1;
	     do{
		
	    	 System.out.print(x++);
	    	 System.out.print("  ");
	       }
	     while(x<10);
	
	     	System.out.println();
	     	System.out.println("-------------------------------");

	     	for(i=1;i<10;i++)
	     	{
	     		System.out.print(i+"|");
	     		for(j=1;j<=9;j++)
	     		{
	     			System.out.print(i*j);
	     			System.out.print("  ");
	     		}
	     		System.out.println();
	     	}
	}

}
