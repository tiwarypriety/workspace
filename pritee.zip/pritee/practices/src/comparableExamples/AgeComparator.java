package comparableExamples;

public class AgeComparator {

}
