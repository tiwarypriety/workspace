package fileIo;

public class Main {
	
	
	void f(){
		System.out.println("hrrrl");
	}

	public static void main(String[] args) {
		
		
		
		Main m =null;;
		m.f();
	}

}
