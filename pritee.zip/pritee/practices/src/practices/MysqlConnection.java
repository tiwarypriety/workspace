package practices;

public class MysqlConnection implements Connection{

	@Override
	public void getConnection() {
		System.out.println("Mysql Connection");
	}

}
