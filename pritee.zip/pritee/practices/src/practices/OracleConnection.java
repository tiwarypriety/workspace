package practices;

public class OracleConnection implements Connection {

	@Override
	public void getConnection() {
		System.out.println("Oracle Connection");
	}

}
