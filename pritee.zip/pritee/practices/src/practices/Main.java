package practices;

public class Main {

	public static void main(String[] args) {
		Connection c = ConnectionFactory.getConnectionMethod("mysql");
			c.getConnection();	
	}

}
