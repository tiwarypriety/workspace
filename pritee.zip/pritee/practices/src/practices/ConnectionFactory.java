
package practices;

public class ConnectionFactory {
static Connection getConnectionMethod(String str){
	if(str.equalsIgnoreCase("mysql")){
		return new MysqlConnection();
	}
	else{
		return new OracleConnection();
	}
}


}
