package practices;

public interface Connection {

	void getConnection();

}
