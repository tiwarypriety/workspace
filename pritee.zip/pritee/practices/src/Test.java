import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {

		File f = new File("d:/hello3.txt");
		try{
			FileReader read = new FileReader(f);
		boolean createNewFile = f.createNewFile();
		System.out.println("File Created = "+createNewFile);
		}catch(Exception e ){
			System.out.println(e);
		}
	}
}
