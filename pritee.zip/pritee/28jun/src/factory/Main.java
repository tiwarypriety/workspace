package factory;

import java.sql.Connection;

import connection.ConnectionI;

public class Main {

	public static void main(String[] args) {
		ConnectionI c = ConnectionFactory.getConnectionMethod("oracle");
						c.getConnection();	
			
	}

}
