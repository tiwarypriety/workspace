package operations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import EmployeePojo.Employee;
import connection.ConnectionI;
import factory.OracleConnection;

public class EmployeeDAO implements EmployeeDAOI
{

	Connection con;
	ConnectionI c ;
	ResultSet rs ;
	PreparedStatement pst ;
	
	@Override
	public ArrayList<Employee> display() 
	{
		ArrayList<Employee> employee1 = new ArrayList<Employee>();
		try{
			c = new OracleConnection();
			con = c.getConnection();
		con.setAutoCommit(false);
		String str = "select * from oneemployee";
		
		pst = con.prepareStatement(str);
	
		rs = pst.executeQuery();


			while(rs.next())
			{
				Employee e = new Employee();
				e.setId(rs.getInt(1));					
				e.setName(rs.getString(2));
				e.setSalary(rs.getInt(3));		
				employee1.add(e);
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		finally
		{
			
			try {
				con.commit();
				con.close();
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		
				return employee1;
	}

	
	
	
	
	@Override
	public int deleteEmployee(Employee e) 
	{
		int d = 0;
		try
		{
			c = new OracleConnection();
			con = c.getConnection();
		con.setAutoCommit(false);
		String str = "delete from oneemployee where id = "+e.getId();		
		pst = con.prepareStatement(str);	
		d = pst.executeUpdate();

		}
		catch(SQLException ex)
		{
			System.out.println(ex);
		}
		finally
		{
			
			try
			{
				con.commit();
				con.close();
			} catch (SQLException ex)
			{
				ex.printStackTrace();
			}
		}
		return d;
	}

	
	
	
	@Override
	public int updateEmployee(Employee e) 
	{
		int d = 0;
		try
		{
			c = new OracleConnection();
			con = c.getConnection();
		con.setAutoCommit(false);
		String str = "update oneemployee set  salary = "+e.getSalary()+" where id = "+e.getId();		
		pst = con.prepareStatement(str);	
		d = pst.executeUpdate();

		}
		catch(SQLException ex)
		{
			System.out.println(ex);
		}
		finally
		{
			
			try
			{
				con.commit();
				con.close();
			} catch (SQLException ex) 
			{
				ex.printStackTrace();
			}
		}
		return d;		
	}
	
	
	
	
	public ArrayList<Employee> viewEmployeeById(int id)
	{
		ArrayList<Employee> employee2 = new ArrayList<Employee>();
		try
		{
			c = new OracleConnection();
			con = c.getConnection();
			con.setAutoCommit(false);
		String str = "select * from oneemployee where id =" +id;
		
		pst = con.prepareStatement(str);	
		rs = pst.executeQuery();
		
			while(rs.next())
			{
				Employee e = new Employee();
				e.setId(rs.getInt(1));			
				e.setName(rs.getString(2));
				e.setSalary(rs.getInt(3));		
				employee2.add(e);
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		finally
		{
			
			try 
			{
				con.commit();
				con.close();
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return employee2;
	}
	
	
	
	
	
	public ArrayList<Employee> viewEmployeeByName(String name)
	{
		ArrayList<Employee> employee3 = new ArrayList<Employee>();
		try
		{
			c = new OracleConnection();
			con = c.getConnection();
			con.setAutoCommit(false);
		String str = "select * from oneemployee where name = "+"name";		
		pst = con.prepareStatement(str);
	
		rs = pst.executeQuery();
System.out.println(rs.next());

			while(rs.next())
			{
				Employee e = new Employee();
				e.setId(rs.getInt(1));			
				e.setName(rs.getString(2));
				e.setSalary(rs.getInt(3));		
				employee3.add(e);
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		finally
		{
			
			try 
			{
				con.commit();
				con.close();
				
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return employee3;		
	}





	@Override
	public int insertRecord(Employee e) {
		int g = 0;
	//	ArrayList<Employee> employee4 = new ArrayList<Employee>();
		try
		{
			c = new OracleConnection();
			con = c.getConnection();
			con.setAutoCommit(false);
		String str = "insert into oneemployee(id,name,salary) values('"+e.getId()+"','"+e.getName()+"','"+e.getSalary()+"')";		
		pst = con.prepareStatement(str);	
		
       /* pst.setInt(1,e.getId());
        pst.setString(2,e.getName());
        pst.setDouble(3,e.getSalary());*/
        
        g = pst.executeUpdate();
		}
		catch(SQLException ex)
		{
			System.out.println(ex);
		}
		finally
		{
			
			try 
			{
				con.commit();
				con.close();
				
			} catch (SQLException ex) 
			{
				ex.printStackTrace();
			}
		}
		return g;		
	}
}
