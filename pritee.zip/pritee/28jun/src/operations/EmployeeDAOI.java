package operations;
import java.util.ArrayList;

import EmployeePojo.Employee;

public interface EmployeeDAOI {
	
	public ArrayList<Employee>  display();
	public int deleteEmployee(Employee e);
	public int updateEmployee(Employee e);
	public ArrayList<Employee> viewEmployeeById(int i);
	public ArrayList<Employee> viewEmployeeByName(String s);
	public int insertRecord(Employee e);
	
	
}
