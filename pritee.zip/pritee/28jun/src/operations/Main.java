package operations;
import java.util.ArrayList;
import java.util.Scanner;

import EmployeePojo.Employee;

public class Main {

	public static void main(String[] args)
	{
		EmployeeDAOI emp = new EmployeeDAO();
		Employee e = new Employee();
		System.out.println("Enter Your Choice");
		System.out.println("1 : To View all Employee Details ");
		System.out.println("2 : To View Specific Employee");
		System.out.println("3 : To delete any employee");
		System.out.println("4 : To Update any employee");
		System.out.println("5 : To insert new Records");
		System.out.println("0 : To Exit");
		int n;
		do{
		
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		switch(n)
		{
			case 1 : 
				
					ArrayList<Employee> lst = emp.display();
					for(Employee e1:lst)
					{
						System.out.println(e1.getId()+" "+e1.getName()+" "+e1.getSalary());
					}     
						break;
			case 2 :
			 	
					System.out.println("Press 1 to view by ID");
					System.out.println("press 2 to view by Name");
				int x = sc.nextInt();
				if(x==1){
					System.out.println("Enter Id");
					int z = sc.nextInt();
					e.setId(z);
					ArrayList<Employee> list = emp.viewEmployeeById(e.getId());
					for(Employee e1:list)
					{
						System.out.println(e1.getId()+" "+e1.getName()+" "+e1.getSalary());
					}     
					}
				else if(x==2){
					System.out.println("Enter Name");
					String z = sc.next();
					e.setName(z);
					ArrayList<Employee> list = emp.viewEmployeeByName(e.getName());
					for(Employee e1:list)
					{
						System.out.println(e1.getId()+" "+e1.getName()+" "+e1.getSalary());
					}   
				}
				break;
				
			case 3 : 
					System.out.println("Enter Id to delete to delete the record");
					int z = sc.nextInt();
					e.setId(z);
				int p = emp.deleteEmployee(e);
				if(p>0)
					System.out.println(p+ " Records deleted!!");
				else
					System.out.println("No Records deleted");
			          break;
			          
			          
			case 4 : 
				System.out.println("Enter Id to Update");
				int r = sc.nextInt();
				e.setId(r);
				System.out.println("Enter the new Salary");
				int s = sc.nextInt();
				e.setSalary(s);
				int t = emp.updateEmployee(e);
				System.out.println(t+ " Records Updated!!");
				break;
				
			case 5 : 
				System.out.println("Enter ID");
				int k = sc.nextInt();
				e.setId(k);
				System.out.println("Enter Name");
				String l = sc.next();
				e.setName(l);
				System.out.println("Enter salary");
				int m = sc.nextInt();
				e.setSalary(m);
				int y = emp.insertRecord(e);
				System.out.println(y+ " Records inserted");
					
			case 0 : 
				System.out.println("Exit");
				break;
		}
		}while(n!=0);
	}

}
