package com.nucleus.service;

import com.nucleus.pojo.Customer;

public interface ServiceI {
	public Boolean service(Customer cus,char ch);
}
