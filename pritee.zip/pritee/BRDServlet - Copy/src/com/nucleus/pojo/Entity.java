package com.nucleus.pojo;

public class Entity {

private int code;
private String name;


public int getCode() {
	return code;
}
public String getName() {
	return name;
}
public void setCode(int code) {
	this.code = code;
}
public void setName(String name) {
	this.name = name;
}
	
}
