package com.nucleus.connection;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;

import com.nucleus.connection.ConnectionI;

public class OracleConnection implements ConnectionI 
{

	Connection con = null;
	@Override
	public Connection getConnection()
	{
		try
		{		
			String		url = null ;
			String  	user = null ;
			String 		pass = null ;
			BufferedReader br = new BufferedReader(new FileReader("D:\\sonal\\BRDServlet\\property.txt"));
			String c;
			while((c = br.readLine())!=null)		
					{
				String s[] = c.split(",",-1);
					url =  s[0];
				 	user = s[1];
					pass = s[2];
					}
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			con = DriverManager.getConnection(url ,user,pass);
			System.out.println("Connection Established");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

}
