package com.nucleus.validation;

import java.util.HashSet;

import com.nucleus.pojo.Customer;

public interface ValidationI {
	public boolean checkNull(Customer c);
	public boolean checkName(String s);
	public boolean checkPinCode(int i);
	public boolean checkContact(Long i);
	public boolean	checkEmailFormat(String email);
	public boolean checkRecordStatus(String s);
	public boolean checkFlag(String s);
	public boolean fileFormat(String fileName);
	public boolean code(String code);
	public boolean checkDate(String strDate);
	
}
