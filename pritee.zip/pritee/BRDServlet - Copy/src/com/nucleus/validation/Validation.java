package com.nucleus.validation;
import java.awt.List;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;

import com.nucleus.pojo.Customer;

public class Validation implements ValidationI
{
	public boolean checkNull(Customer c)
	{
		
		if(c.getCode().isEmpty()||c.getName().isEmpty()||c.getPin_code()==0||c.getEmail().isEmpty()||c.getRecordStatus().isEmpty()||c.getFlag().isEmpty()||c.getContact_number()==0)
		return false;
		return true;
	}

	public boolean checkName(String s)
	{		
		if(s.length()<=30)
		{
		 if(s.matches("[A-Za-z 0-9]+"))
			return true;
		}		
		return false;
	}
	public boolean checkPinCode(int i){
		int j = String.valueOf(i).length();
		if(j==6)
		return true;
		else
		return false;
	}
	public boolean checkContact(Long i)
	{
		int j = String.valueOf(i).length();
		if(j==10)
		return true;
		else
		return false;
	}	
	public boolean	checkEmailFormat(String email)
	{		
	    if(email.contains("@")&&(email.endsWith(".com")))
	    {
	    	 return true;
	    }
	return false;		
	}	
	public boolean checkRecordStatus(String s)
	{
		if(s.charAt(0)=='N'||s.charAt(0)=='M'||s.charAt(0)=='D'||s.charAt(0)=='A'||s.charAt(0)=='R')
		return true;
		return false;
	}
	public boolean checkFlag(String s)
	{
		if(s.charAt(0)=='A'||s.charAt(0)=='I')
		return true;
		return false;
	}
	public boolean fileFormat(String fileName)
	{
		   return fileName.endsWith(".txt");
	}
	/*public boolean code(Customer cus , HashSet set)
	{		
		if(cus.getCode().length()>10)
		{
			return false;
		}
		else if(cus.getCode().equals(""))
		{
			return false;
		}
		
		else if(set.contains(cus.getCode()))
			{
			return false;
			}
	
			return true;
	}*/

	public boolean code(String code) {
		
		if(code.length()>10)
		{
			return false;
		}
		return true;
	}
	public boolean checkDate(String strDate)
	{
		SimpleDateFormat sdfrmt = new SimpleDateFormat("dd/MMM/yyyy");
	    //sdfrmt.setLenient(false);
	    try
	    {
	        Date javaDate = sdfrmt.parse(strDate); 
	    }
	
	    catch (ParseException e)
	    {
	        System.out.println(" Invalid Date format");
	        return false;
	    }

	    	return true;
	}
	
}

