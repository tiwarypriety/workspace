package program3;

import java.util.Scanner;

public class Main {
   public static void main(String a[]){ 
   int x;
   String model = null;
      Category c = new Category();
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter the choices for Category:");
       System.out.println("1  : SUV ");
       System.out.println("2  : SEDAN");
       System.out.println("3  : ECONOMY ");
       System.out.println("4  : MINI ");
       System.out.println("0  : EXIT ");
       do{
       x = sc.nextInt();
       switch(x){
           case 1 : 
                 model = c.modelOfCategory("SUV");
                 System.out.println(model);
                 break;
           case 2 :
               model = c.modelOfCategory("SEDAN");
               System.out.println(model);
                 break;
           case 3 : 
               model = c.modelOfCategory("ECONOMY");
               System.out.println(model);
               break;
           case 4 :
               model = c.modelOfCategory("MINI");
               System.out.println(model);
               break;
           case 0 :
           System.out.println("Exit");
                 break;      
       }
             
       }while(x!=0);  
   }
 
}

