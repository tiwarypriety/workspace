package program2;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args)
	{
		Door d=new Door();
		Window w=new Window();
		BankAccount b=new BankAccount();
		System.out.println("Choose an option");
		Scanner sc=new Scanner(System.in);
		System.out.println("1 : for opening door");
		System.out.println("2 : for opening window");
		System.out.println("3 : for opening bank account");
		int n=sc.nextInt();
		switch(n)
		{
			case 1:
					d.open();
					break;
			case 2:
					w.open();
					break;
			case 3:
					b.open();
					break;
			default:
					System.out.println("invalid input");
		}
	}
}


