package program2;
class Open
{
	void open()
	{
		System.out.println("parent class method");
	}
}
class Door extends Open
{
	int noOfGates=3;
	void open()
	{
		System.out.println("open the door....No of gates is "+noOfGates);
	}
}
class Window extends Open
{
	String windowType="Glass Window";
	void open()
	{
		System.out.println("open the window!....Window Type is "+ windowType);
	}
}
class BankAccount extends Open
{
	String accNo="564JKL79980";
	String bankName="PNB";
	void open()
	{
		System.out.println("open a bank account in "+bankName+" acc no is "+accNo);
	}
}


