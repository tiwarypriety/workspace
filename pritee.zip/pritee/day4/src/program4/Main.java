package program4;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Volume v = new Volume();
      System.out.println(v.volume(5));   //calculate and print the volume of cube
      System.out.println( v.volume(5,10)); //calculate and print the volume of cylinder
      System.out.println(v.volume(10, 30, 15));//calculate and print the volume of rectangle
	}
}
