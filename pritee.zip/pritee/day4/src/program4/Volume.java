package program4;

public class Volume
{
	final double pi =3.14;
double volume(double s)
{
return s*s*s;
}
double volume(double r,double h)
{
return pi*r*r*h;
}
double volume(double l,double b,double h)
{
return l*b*h;
}
}
