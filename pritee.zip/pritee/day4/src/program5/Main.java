package program5;

public class Main
{
	public static void main(String[] args) 
	{
		HourlyWorker h = new HourlyWorker("JOHN",10);
		h.display();
		h.computePay(70);
		SalariedWorker s = new SalariedWorker("Jinny",20);
		s.display();
		s.computePay();
	}
}
