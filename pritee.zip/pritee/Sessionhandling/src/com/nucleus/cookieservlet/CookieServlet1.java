package com.nucleus.cookieservlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CookieServlet1")
public class CookieServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CookieServlet1() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String username = request.getParameter("username");
		System.out.println("cookie servlet");
		Cookie cookie1 = new Cookie("User1",username);
		Cookie cookie2 = new Cookie("User2",username);
		Cookie cookie3 = new Cookie("User3",username);
		Cookie cookie4 = new Cookie("User4",username);
		response.addCookie(cookie1);
		response.addCookie(cookie2);
		response.addCookie(cookie3);
		response.addCookie(cookie4);
		RequestDispatcher rd = request.getRequestDispatcher("CookieServlet2");
		rd.forward(request, response);
	}
}
