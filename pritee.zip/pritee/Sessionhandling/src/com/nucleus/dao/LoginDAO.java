package com.nucleus.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionI;
import com.nucleus.connection.OracleConnection;
public class LoginDAO implements LoginDAOI
{
	
	Connection con  = null;
	ConnectionI ci = null;
	PreparedStatement pst = null ;
	ResultSet rs = null;
	int rowsaffected = 0;
	public boolean login(String u,String p )
	{
		try
		{
			
			ci = new OracleConnection();
			con = ci.getConnection();
			String username = null;
			String password = null;
			
		String str = "select * from Login1909 where username = ?";
		
		pst = con.prepareStatement(str);	
        pst.setString(1,u);
       rs = pst.executeQuery();
     while(rs.next())
     {
        	username = rs.getString(1);
        	password =	rs.getString(2);
     }  	
 
       if(u.equals(username)&&p.equals(password))
       {
        System.out.println("Logged in!!");
        return true;
       }
       else
       {
    	   return false;
       }
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
			  return false;
		}


	}
	@Override
	public boolean insertRecord(String u, String p) {
		int rowsaffected = 0;
		try
		{
			if(con==null)
			{
			ci = new OracleConnection();
			con = ci.getConnection();
			}
			con.setAutoCommit(false);
			
		String str = "insert into Login1909 values(?,?) ";
		
		pst = con.prepareStatement(str);	
	
        pst.setString(1,u);
        pst.setString(2,p);
   
        rowsaffected = pst.executeUpdate();	  
        if(rowsaffected>0)
        {
        	System.out.println(rowsaffected);
        	return true;
        }
        else
        {
        	System.out.println(rowsaffected);
        	return false;
        }
		}
		catch(SQLException ex)
		{

			System.out.println("Record Already Exist in Database");
			return false;
		}
					
	
	}
	
	

	}
	


