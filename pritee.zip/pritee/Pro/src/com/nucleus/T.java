package com.nucleus;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/T")
public class T extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public T() {
        super();  
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String username = request.getParameter("user");
		String password = request.getParameter("password");
			if(username.equals("nucleus"))
			{
				if(password.equals("nucleus"))
				{
					p.println("Login successful");
				}
				else
				{
					p.println("Invalid password");
				}
			}
			else
			{
				p.println("invalid Username");
			}	
			
	}
}
