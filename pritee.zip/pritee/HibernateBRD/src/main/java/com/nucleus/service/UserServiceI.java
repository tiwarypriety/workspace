package com.nucleus.service;


import com.nucleus.model.Role;
import com.nucleus.model.User;

public interface UserServiceI 
{
	public boolean addUser(User user);
	public boolean role(User u,Role role);
	public boolean exists(String user);
	public boolean addAdmin(User user);
}
