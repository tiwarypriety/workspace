package com.nucleus.model;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name ="customer1909")
public class Customer extends BaseEntity implements Serializable
{
	

	@NotEmpty
	@NumberFormat(style=Style.NUMBER) 
	@Length(min=6,max=6)
	@Column(name = "cpin")
	private String pin;
	@NotEmpty
	@NumberFormat(style=Style.NUMBER) 
	@Length(min=10,max=10)
	@Column(name = "cnumber")
	private String number;
	@Column(name = "ccreatedate")
	private String createdDate;	
	@Column(name = "ccreateby")
	private String createdBy;	
	@Column(name = "cmodifiedDate")
	private String modifiedDate;
	
	
	
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String date1) {
		this.modifiedDate = date1;
	}
	@Override
	public String toString() {
		return "Customer [pin=" + pin + ", number=" + number + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	
	
}
