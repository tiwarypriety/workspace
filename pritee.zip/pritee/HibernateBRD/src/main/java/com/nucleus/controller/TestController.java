package com.nucleus.controller;

import java.security.Principal;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.nucleus.model.Customer;
import com.nucleus.model.User;
import com.nucleus.service.CustomerServiceI;
import com.nucleus.service.UserServiceI;
import org.apache.log4j.Logger; 


@Controller
public class TestController 
{
	@Autowired
	UserServiceI service;
	@Autowired
	CustomerServiceI cs;
	@Autowired
	private MessageSource ms;

	final static Logger logger=Logger.getLogger(com.nucleus.controller.TestController.class);
	
	@RequestMapping(value ="/addpage",method= RequestMethod.GET)
	public String  addpage(@ModelAttribute("customer") Customer customer,BindingResult result)
	{	
					return ms.getMessage("a", null,"not Found",null); 
	}
	@RequestMapping(value ="/updatepage",method= RequestMethod.GET)
	public String  updatepage()
	{
					return ms.getMessage("b", null,"not Found",null); 		
	}
	@RequestMapping(value ="/deletepage",method= RequestMethod.GET)
	public ModelAndView  deletepage(Principal principal)
	{			
					String username = principal.getName();		
					return new ModelAndView(ms.getMessage("c", null,"not Found",null),"username",username);				
	}
	@RequestMapping(value ="/logout",method= RequestMethod.GET)
	public String  logout()
	{	
					return ms.getMessage("d", null,"not Found",null);			
	}
	@RequestMapping(value ="/viewpage",method= RequestMethod.GET)
	public ModelAndView  view(Principal principal)
	{		
					String username = principal.getName();				
					return new ModelAndView(ms.getMessage("e", null,"not Found",null),"username",username);			
	}
	@RequestMapping(value ="/viewbydate",method= RequestMethod.GET)
	public String  byDate()
	{	
					return ms.getMessage("f", null,"not Found",null);	
	}
	@RequestMapping(value ="/viewby",method= RequestMethod.GET)
	public String  view()
	{	
					return ms.getMessage("g", null,"not Found",null);	
	}
	@RequestMapping(value ="/viewbychar",method= RequestMethod.GET)
	public String  view1()
	{	
					return ms.getMessage("h", null,"not Found",null);	
	}
	@RequestMapping(value="/userpage", method= RequestMethod.GET)
	public ModelAndView userpage(Principal principal)
	{
					String username = principal.getName();
					return new ModelAndView(ms.getMessage("i", null,"not Found",null),"username",username);					
	}	

	@RequestMapping(value="/adminpage", method= RequestMethod.GET)
	public String adminpage()
	{
					return ms.getMessage("j", null,"not Found",null);			
	}
			
	@RequestMapping(value="/user", method= RequestMethod.GET)
	public ModelAndView user(@ModelAttribute("user") User user,Principal principal)
	{			
					String username = principal.getName();		
					return new ModelAndView(ms.getMessage("k", null,"not Found",null),"username",username);			
	}

	@RequestMapping(value="/admin", method= RequestMethod.GET)
	public ModelAndView admin(@ModelAttribute("user") User user,Principal principal)
	{		
					String username = principal.getName();		
					return new ModelAndView(ms.getMessage("l", null,"not Found",null),"username",username);	
	}
	
//******************************************SAVE USER**********************************************************		
	@RequestMapping(value="/adduser", method= RequestMethod.POST)
	public ModelAndView adduser(@Valid @ModelAttribute("user") User user,BindingResult result,Principal principal)
	{
			ModelAndView view;
			try
			{
						
					logger.info("INSERTING USER");
					String username = principal.getName();		
					boolean exist = service.exists(user.getUserId());
					System.out.println(exist);
					if(!exist)
					{										 
									boolean res = service.addUser(user);
									if(res)
									{
										view=new ModelAndView(ms.getMessage("j", null,"not Found",null),"message","User Added!!");
									}
									else
									{
									 view=new ModelAndView(ms.getMessage("m", null,"not Found",null),"message","Something went Wrong!!");
									} 
									return view;
					}
					else
					{
						view=new ModelAndView(ms.getMessage("k", null,"not Found",null),"message","Userid already Exist in database!!");
						return view;
					}
			}
			catch(Exception e)
			{
				logger.warn("Problem occured while INSERTING USER");
				logger.error(e.getMessage());
			}
			return new ModelAndView(ms.getMessage("k", null,"not Found",null),"message","Some Error Occured!!");			
		}
	
//******************************************SAVE ADMIN**********************************************************	
	@RequestMapping(value="/addadmin", method= RequestMethod.POST)
	public ModelAndView addadmin(@Valid @ModelAttribute("user") User user,BindingResult result,Principal principal)
	{
			ModelAndView view;
			try
			{
					logger.info("INSERTING ADMIN");
					if(result.hasErrors())
					{				
						return new ModelAndView(ms.getMessage("m", null,"not Found",null),"message","Something went Wrong!!");
					}
					String username = principal.getName();		
					boolean exist = service.exists(user.getUserId());
					if(!exist)
					{
								
								boolean res = service.addAdmin(user);
								if(res)
								{
									view=new ModelAndView(ms.getMessage("j", null,"not Found",null),"message","Admin Added!!");
								}
								else
								{
									view=new ModelAndView(ms.getMessage("m", null,"not Found",null),"message","Something went Wrong!!");							
								} 
								return view;
					}
					else
					{
							view=new ModelAndView(ms.getMessage("l", null,"not Found",null),"message","Userid already Exist in database!!");
							return view;
					}
			}
			catch(Exception e)
			{
				logger.warn("Problem occured while INSERTING ADMIN");
				logger.error(e.getMessage());
			}
			return new ModelAndView(ms.getMessage("l", null,"not Found",null),"message","Some Error Occured!!");
	}

//************************************SAVE CUSTOMER**********************************************************	
	@RequestMapping(value="insert", method= RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Principal p)
	{      			
		try
		{
					logger.info("INSERTING CUSTOMER");
					if(result.hasErrors())
					{				
						return new ModelAndView(ms.getMessage("a", null,"not Found",null),"message","Something went Wrong!!");
					}
					boolean exist = cs.exists(customer.getCode());	
					if(!exist)
					{
					customer.setCreatedBy(p.getName());
					boolean res = cs.addCustomer(customer);
								if(res)
								{
									return	new ModelAndView(ms.getMessage("a", null,"not Found",null),"message"," Record inserted in Database!!");
								}
								else
								{
									return	new ModelAndView(ms.getMessage("a", null,"not Found",null),"message"," Record not inserted!!");
								}
					}
					else
					{
						return	new ModelAndView(ms.getMessage("a", null,"not Found",null),"message"," code already exist in Database!!");
						
					}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING ADDING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView(ms.getMessage("a", null,"not Found",null),"message","Some Error Occured!!");			
	}
	
//************************************DELETE CUSTOMER**********************************************************	
	@RequestMapping(value="delete", method= RequestMethod.POST)
	public ModelAndView deleteCustomer(@ModelAttribute("customer") Customer customer,Principal principal)
	{
		try
		{		
					logger.info("DELETING CUSTOMER");
					boolean exist = cs.exists(customer.getCode());
					boolean res;
					if(exist)
					{
							res = cs.deleteCustomer(customer);
					}
					else
					{
							return	new ModelAndView(ms.getMessage("c", null,"not Found",null),"message"," Code Doesn't Exist  in database!!!");
					}
					if(res)
					{
							ModelAndView view=new ModelAndView(ms.getMessage("c", null,"not Found",null),"message"," Record Deleted!!!");
							return view;
					}
					else
						
					{
							ModelAndView view=new ModelAndView(ms.getMessage("m", null,"not Found",null));
							return view;
					}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING DELETING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView(ms.getMessage("c", null,"not Found",null),"message","Some Error Occured!!");		
	}
//************************************UPDATE CUSTOMER**********************************************************
	@RequestMapping(value ="update",method= RequestMethod.POST)
	public ModelAndView  update( @ModelAttribute("customer") Customer customer,Principal principal)
	{
		try
		{
					logger.info("UPDATING CUSTOMER");
					boolean exist = cs.exists(customer.getCode());
					if(exist)
					{
							
							Customer c = cs.viewCustomer(customer);
							return	new ModelAndView(ms.getMessage("n", null,"not Found",null),"customer",c);	
					}
					else
					{
						return	new ModelAndView(ms.getMessage("o", null,"not Found",null),"message"," Code Doesn't Exist  in database!!!");
					}
						
		
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING UPDATING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView(ms.getMessage("o", null,"not Found",null),"message","Some Error Occured!!");
	
	}	
//************************************UPDATE CUSTOMER**********************************************************
	@RequestMapping(value="updatecust", method= RequestMethod.POST)
	public ModelAndView updateCustomer(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Principal principal)
	{
		try
		{
			    logger.info("UPDATING CUSTOMER");
				if(result.hasErrors())
				{				
					return	new ModelAndView(ms.getMessage("m", null,"not Found",null));
				}
				else
				{
					boolean exist = cs.exists(customer.getCode());
					boolean res;
					if(exist)
					{
					 res = cs.updateCustomer(customer);
					}
					else
					{
						return	new ModelAndView(ms.getMessage("n", null,"not Found",null),"message"," Code Doesn't Exist  in database!!!");
					}
					if(res)
					{
						ModelAndView view=new ModelAndView(ms.getMessage("o", null,"not Found",null),"message"," Record Updated!!!");
						return view;
					}
					else
						
					{
						ModelAndView view=new ModelAndView(ms.getMessage("m", null,"not Found",null));
						return view;
					}
				
				}
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while INSERTING UPDATING CUSTOMER");
			logger.error(e.getMessage());
		}
		return new ModelAndView(ms.getMessage("n", null,"not Found",null),"message","Some Error Occured!!");
	
	}
	
//***********************************VIEW SINGLE CUSTOMER*****************************************************
	@RequestMapping(value="single", method= RequestMethod.POST)
	public ModelAndView viewCustomer(@ModelAttribute("customer") Customer customer)
	{		
		try
		{				
						logger.info("VIEW CUSTOMER DETAIL");
						boolean exist = cs.exists(customer.getCode());
						if(exist)
						{
							
							Customer c = cs.viewCustomer(customer);
							return	new ModelAndView(ms.getMessage("p", null,"not Found",null),"customer",c);	
						}
						else
						{
							return	new ModelAndView(ms.getMessage("q", null,"not Found",null),"message"," Code Doesn't Exist  in database!!!");
						}
					
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL");
			logger.error(e.getMessage());
		}
	
	return new ModelAndView(ms.getMessage("q", null,"not Found",null),"message","Some Error Occured!!");
	}
	
//**************************************VIEW ALL DETAILS****************************************************
	@RequestMapping(value="viewall", method= RequestMethod.GET)
	public ModelAndView viewall(@ModelAttribute("customer") Customer customer)
	{
		try
		{	
					logger.info("VIEW ALL CUSTOMER DETAIL");
					List<Customer> list = cs.viewAll();
					return	new ModelAndView(ms.getMessage("r", null,"not Found",null),"cust",list);			
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL");
			logger.error(e.getMessage());
		}
	
	return new ModelAndView(ms.getMessage("r", null,"not Found",null),"message","Some Error Occured!!");	
	}
	
	@RequestMapping(value="bychar", method= RequestMethod.POST)
	public ModelAndView viewByDate(@ModelAttribute("char") String c)
	{
		try
		{					System.out.println(c);
						logger.info("VIEW CUSTOMER DETAIL BY CHAR");		
							
								
								List<Customer>  cust = cs.viewByChar(c);
								return	new ModelAndView(ms.getMessage("r", null,"not Found",null),"cust",cust);	
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL BY DATE");
			logger.error(e.getMessage());
		}	
	return new ModelAndView(ms.getMessage("r", null,"not Found",null),"message","Some Error Occured!!");
	}
//************************************VIEW BY DATE**********************************************************
	@RequestMapping(value="bydate", method= RequestMethod.POST)
	public ModelAndView viewByDate(@ModelAttribute("customer") Customer customer)
	{
		try
		{										
						logger.info("VIEW CUSTOMER DETAIL BY DATE");						
						List<Customer>  c = cs.viewByDate(customer);
						return	new ModelAndView(ms.getMessage("r", null,"not Found",null),"cust",c);	
		}
		catch(Exception e)
		{
			logger.warn("Problem occured while VIEWING CUSTOMER DETAIL BY DATE");
			logger.error(e.getMessage());
		}	
	return new ModelAndView(ms.getMessage("r", null,"not Found",null),"message","Some Error Occured!!");
	}
//************************************VIEW BY ANY DETAIL**********************************************************
	@RequestMapping(value="view", method= RequestMethod.POST)
	public ModelAndView view(@ModelAttribute("detail") String detail)
	{
		try
		{				
						System.out.println("1 : "+detail);
						List<Customer>  c = cs.view(detail);
						return new ModelAndView(ms.getMessage("r", null,"not Found",null),"cust",c);			
		}
		catch(Exception e)
		{
			logger.warn("View");
			logger.error(e.getMessage());
		}	
	return new ModelAndView(ms.getMessage("r", null,"not Found",null),"message","Some Error Occured!!");
	}
}
