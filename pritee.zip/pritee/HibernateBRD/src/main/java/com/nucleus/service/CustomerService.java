package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDaoI;
import com.nucleus.model.Customer;

@Service
public class CustomerService implements CustomerServiceI {
	
	
	@Autowired
	CustomerDaoI cdao;
	
	@Transactional	
	public boolean addCustomer(Customer customer)
	{
		boolean a= cdao.addCustomer(customer);
		if(a)
		return true;
		return false;
	}
	@Transactional	
	public boolean deleteCustomer(Customer customer)
	{
		boolean a= cdao.deleteCustomer(customer);
		if(a)
		return true;
		return false;
	}
	@Transactional	
	public boolean updateCustomer(Customer customer)
	{
		boolean a= cdao.updateCustomer(customer);
		if(a)
		return true;
		return false;
	}
	
	@Transactional
	public Customer viewCustomer(Customer c)
	{
		Customer a= cdao.viewCustomer(c);
			return a;
	}
	@Transactional
	public List<Customer> viewAll() 
	{
		List<Customer>  a = cdao.viewAll();
			
			return a;
	}
	@Transactional
	public boolean exists(String code)
	{
		boolean a= cdao.exists(code);
		if(a)
		return true;
		return false;
	}
	@Transactional
	public List<Customer> viewByDate(Customer c) 
	{		
		List<Customer> a= cdao.viewByDate(c);
		return a;
	}
	@Transactional
	public List<Customer> view(String detail)
	{		
		System.out.println("2: "+detail);
		List<Customer> a= cdao.view(detail);
		return a;
	}
	@Transactional
	public List<Customer> viewByChar(String c)
	{		
		System.out.println("2: "+c);
		List<Customer> a= cdao.viewByChar(c);
		return a;
	}
}
