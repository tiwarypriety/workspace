package com.nucleus.dao;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.Customer;


@Repository
public class CustomerDao implements CustomerDaoI{
	
	@Autowired
    private SessionFactory sf;
		
		@Override
	public boolean addCustomer(Customer customer)
	{
				Date date = Calendar.getInstance().getTime();  
				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");  
				String date1 = dateFormat.format(date);		
				customer.setCreatedDate(date1);
				
				sf.getCurrentSession().save(customer);  		
				return true;		
				
	}
		public boolean deleteCustomer(Customer customer)
		{
			
				String code=  customer.getCode();
	
				/*	Query q = sf.getCurrentSession().createQuery("delete from Customer where customercode=:code1");
				q.setParameter("code1", code);
			
				int t=q.executeUpdate();
				System.out.println(t);*/
				
				Object a = sf.getCurrentSession().get(Customer.class,code);
	
				if(a!=null)
				{
				sf.getCurrentSession().delete(a);
				return true;
				}
				else
				return false;
	
			
		}
		public boolean updateCustomer(Customer c)
		{
		
				Date date = Calendar.getInstance().getTime();  
				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");  
				String date1 = dateFormat.format(date);		
				c.setModifiedDate(date1);
				try
				{
				sf.getCurrentSession().update(c);
				return true;
			
				}
				catch(Exception e)
				{
					System.out.println(e);
					return false;
				}

			
		}
		public Customer viewCustomer(Customer c)
		{
				String code=  c.getCode();
				Customer c1= (Customer) sf.getCurrentSession().get(Customer.class, code);					
				return c1;
		}
		

		public List<Customer> viewByDate(Customer c)
		{
			
			
				String date = c.getCreatedDate();
				Query query=sf.getCurrentSession().createQuery("from Customer where ccreatedate=?");
				query.setParameter(0, date);			
				List<Customer> list=query.list();	
				return list;					
		}
		
		public List<Customer> view(String detail) 
		{
				System.out.println("3: "+detail);
				Query query=sf.getCurrentSession().createQuery("from Customer where customercode = ? or caddress=? or ccreateby=? or ccreatedate=? or cemail=? or cname=? or cnumber =? or cpin=? ");
				query.setParameter(0, detail);	
				query.setParameter(1, detail);
				query.setParameter(2, detail);
				query.setParameter(3, detail);
				query.setParameter(4, detail);
				query.setParameter(5, detail);
				query.setParameter(6, detail);
				query.setParameter(7, detail);
				List<Customer> list=query.list();	
				return list;					
		}
			
		public List<Customer> viewAll() 
		{
			
				Query query=sf.getCurrentSession().createQuery("from Customer");
				List<Customer> list=query.list();
				return list;
			
		}
		
		public boolean exists(String code)
		{
				Object  a =sf.getCurrentSession().get(Customer.class, code) ;				
				if(a!=null)
				{
					return true;
				}				
				return false;
		}
			
		public List<Customer> viewByChar(String c)
		{			
			 if(c.startsWith("*")&&c.endsWith("*"))
			{
				String a = c.replace("*","");
				Query query=sf.getCurrentSession().createQuery("from Customer where cname like ?");
				query.setParameter(0, "%"+a+"%");
				List<Customer> list=query.list();
				return list;	
			}
			else if(c.startsWith("*"))
			{
				String a = c.replace("*","");
				Query query=sf.getCurrentSession().createQuery("from Customer where cname like ?");
				query.setParameter(0, a+"%");	
				List<Customer> list=query.list();
				return list;	
			}
			else if(c.endsWith("*"))
			{
				String a = c.replace("*","");
				Query query=sf.getCurrentSession().createQuery("from Customer where cname like ?");
				query.setParameter(0, "%"+a);
				List<Customer> list=query.list();
				return list;	
				
			}
			
			return null;
			
				
				
								
		}

}
