package com.nucleus.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.controller.PasswordEncoder;
import com.nucleus.dao.UserDaoI;
import com.nucleus.model.Role;
import com.nucleus.model.User;


@Service
public class UserService implements UserServiceI 
{
	@Autowired
	UserDaoI dao;
	
	
	@Transactional	
	public boolean addUser(User user)
	{
		PasswordEncoder p = new PasswordEncoder();	
		String password = user.getPass();											
		String pass= p.encoder(password);
		
		user.setPass(pass);
		
		Role role = new Role();	
		
		role.setRoleid(101);
		role.setRname("ROLE_USER");
		
		user.setRole(role);
		
		user.setEnabled(1);
		
		boolean a= dao.addUser(user);
		if(a)
		return true;
		return false;
	}
	@Transactional
	public boolean addAdmin(User user)
	{
		String password = user.getPass();
		PasswordEncoder p = new PasswordEncoder();
		String pass= p.encoder(password);
		user.setPass(pass);

		Role role = new Role();		
		role.setRoleid(102);
		role.setRname("ROLE_ADMIN");
		
		user.setRole(role);
	
		user.setEnabled(1);
		
		boolean a= dao.addUser(user);
		if(a)
		return true;
		return false;
	}
	@Transactional	
	public boolean role(User u,Role role)
	{
		boolean a= dao.role(u,role);
		if(a)
		return true;
		return false;
	}
	@Transactional	
	public boolean exists(String user)
	{

		boolean a= dao.exists(user);
		if(a)
		return true;
		return false;
			
	}
}
