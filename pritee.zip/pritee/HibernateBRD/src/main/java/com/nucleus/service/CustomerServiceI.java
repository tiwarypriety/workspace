package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Customer;

public interface CustomerServiceI {
	public boolean addCustomer(Customer customer);
	public boolean deleteCustomer(Customer customer);
	public boolean updateCustomer(Customer customer);
	public Customer viewCustomer(Customer customer);
	public List<Customer> viewAll() ;
	public boolean exists(String code);
	public List<Customer>  viewByDate(Customer c);
	public List<Customer> view(String detail);
	public List<Customer> viewByChar(String c);
	
}
