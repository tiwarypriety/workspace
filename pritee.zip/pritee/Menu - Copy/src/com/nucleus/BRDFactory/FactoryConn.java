package com.nucleus.BRDFactory;

import com.nucleus.connection.ConnI;
import com.nucleus.connection.MySQLConn;
import com.nucleus.connection.OracleConn;
import com.nucleus.connection.SQLServerConn;

public class FactoryConn 
{
	public static  ConnI factorymethod(String s)
	{
		if(s.equalsIgnoreCase("oracle"))
	        {
			return new OracleConn();	
	        }
		else if(s.equalsIgnoreCase("mysql"))
			{
			return new MySQLConn(); 
			}
		else if(s.equalsIgnoreCase("sqlserver"))
			{
			return new SQLServerConn();
			}
		else return null;
	}
}
