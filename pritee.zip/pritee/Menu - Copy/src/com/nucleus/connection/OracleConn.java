package com.nucleus.connection;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConn implements ConnI
{

	Connection conn=null;
	public Connection myConnection()
	{
		try{
			FileReader r=new FileReader("d:/sakship/BRD-Maker-Checker/src/connection.properties");
			Properties p=new Properties();
			p.load(r);
			String url=p.getProperty("url");
			String username=p.getProperty("username");
			String password=p.getProperty("password");
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());//to load driver
			conn=DriverManager.getConnection("jdbc:oracle:thin:@"+url+":1521:orcl",username,password);//loading driver
			//conn=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");//loading driver
			r.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		return conn;
	}
	
}
