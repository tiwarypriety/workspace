package com.nucleus.connection;

import java.sql.Connection;

public interface ConnI 
{
	 public Connection myConnection();
}
