package com.nucleus.connection;

import java.sql.Connection;

public class SQLServerConn implements ConnI
{
	@Override
	public Connection myConnection()
	{	
		return null;
	}

}
