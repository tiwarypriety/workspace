package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String ho=request.getParameter("Home");
		String c=request.getParameter("Contact");
		String a=request.getParameter("About Us");
		String he=request.getParameter("Help");
		String n=request.getParameter("New User");
		String l=request.getParameter("Login");
		PrintWriter p=response.getWriter();
		
		if(ho!=null&& ho.equalsIgnoreCase("home")&&request.getSession(false)!=null)
		{
			p.println("else case1");
			HttpSession s=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("Home1.jsp");
			rd.forward(request, response);
		}
		else if(c!=null&&c.equalsIgnoreCase("contact")&&request.getSession(false)!=null)
		{
			p.println("else cas0e2");
			HttpSession s=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("Contact.jsp");
			rd.forward(request, response);
		}
		else if(a!=null&&a.equalsIgnoreCase("about us")&&request.getSession(false)!=null)
		{
			p.println("else case3");
			HttpSession s=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("AboutUs.jsp");
			rd.forward(request, response);
		}
		else if(he!=null&&he.equalsIgnoreCase("help")&&request.getSession(false)!=null)
		{
			p.println("else case4");
			HttpSession s=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("Help.jsp");
			rd.forward(request, response);
		}
		else if(n!=null&&n.equalsIgnoreCase("new user"))
		{
			p.println("else case5");
			RequestDispatcher rd=request.getRequestDispatcher("RegisterMenu.jsp");
			rd.forward(request, response);
		}
		else if(l!=null&&l.equalsIgnoreCase("login"))
		{
			p.println("else case6");
			RequestDispatcher rd=request.getRequestDispatcher("LoginMenu.jsp");
			rd.forward(request, response);
		}
		else
		{
			p.println("else case");
			System.out.println("el;se");
		RequestDispatcher rd=request.getRequestDispatcher("CreateSession.jsp");
		rd.forward(request,response);
		}
	}

	
}
