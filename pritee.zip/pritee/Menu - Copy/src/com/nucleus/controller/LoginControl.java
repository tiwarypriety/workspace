package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.LoginDAO;
import com.nucleus.dao.LoginDAOI;

@WebServlet("/LoginControl")
public class LoginControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	LoginDAOI dao=new LoginDAO();
	PrintWriter p=response.getWriter();
	if(dao.checkDetails(request.getParameter("user"),request.getParameter("pass")))
	{
		p.println("Login Successful...");
		RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
		rd.forward(request, response);
	}
	else
	{
		p.println("Incorrect Username or Password!!!Try again...");
		RequestDispatcher rd=request.getRequestDispatcher("LoginMenu.jsp");
		rd.forward(request, response);
	}
	}
	
}
