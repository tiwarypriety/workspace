package com.nucleus.service;

import com.nucleus.dao.LoginDAO;
import com.nucleus.dao.LoginDAOI;

public class LoginRegService 
{
	 LoginDAOI dao=new LoginDAO();
 public boolean checkDao(String s1,String s2)
 {
	 boolean i=dao.checkDetails(s1, s2);
	 return i;
	 
 }
 public int insertDetails(String s1,String s2)
 {
	 int i=dao.insertDetails(s1,s2);
	 return i;
 }
}
