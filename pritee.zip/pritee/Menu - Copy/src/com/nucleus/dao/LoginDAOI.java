package com.nucleus.dao;

public interface LoginDAOI 
{
	public boolean checkDetails(String s1,String s2);
	public int insertDetails(String s1,String s2);
}
