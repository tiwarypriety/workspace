package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.nucleus.BRDFactory.FactoryConn;
import com.nucleus.connection.ConnI;
public class LoginDAO implements  LoginDAOI
{
	Connection conn=null;
	ConnI c=null;
	PreparedStatement ps=null;
	public boolean checkDetails(String s1,String s2)
	{
		boolean incnt=false;
    	try
    	{ 
    		String username = null , password=null;
    		c=FactoryConn.factorymethod("oracle");
			conn=c.myConnection();
			ResultSet r=null;
			ps=conn.prepareStatement("select * from SCustLogin where username=? and passkey=? ");
    			ps.setString(1,s1);
    			ps.setString(2,s2);
    			ps.executeQuery();
    			r= ps.executeQuery();
    			while(r.next())
        		{
        		 username = r.getString(1);
        		 password=r.getString(2);
        		 if(username.equals(s1)&&password.equals(s2))
        			 incnt=true;;
        		}
    			
    				
    	}catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	finally
		{
			try{
				conn.commit();
				conn.close();
				ps.close();
			   }catch(Exception e)
			   {
				   e.printStackTrace();
			   }
		}
    	return incnt;
	}
	@Override
	public int insertDetails(String s1, String s2) 
	{
		int i=0;
		try
    	{ 
    		c=FactoryConn.factorymethod("oracle");
			conn=c.myConnection();
			ps=conn.prepareStatement("insert into SCustLogin values(?,?)");
    			ps.setString(1,s1);
    			ps.setString(2,s2);
    			ps.executeQuery();
    			i= ps.executeUpdate();		
    	}catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	finally
		{
			try{
				conn.commit();
				conn.close();
				ps.close();
			   }catch(Exception e)
			   {
				   e.printStackTrace();
			   }
		}
		return i;
	}


}
