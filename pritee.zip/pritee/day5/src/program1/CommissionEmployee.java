package program1;

public class CommissionEmployee {

}
