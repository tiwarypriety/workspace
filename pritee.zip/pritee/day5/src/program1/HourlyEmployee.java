package program1;

public class HourlyEmployee {

}
