package program1;

public class Employee {

}
