package program1;

public class SalariedEmployee {

}
