package com.nucleus.connection;

import java.sql.Connection;

import com.nucleus.connection.ConnectionI;

public class MysqlConnection implements ConnectionI
{

	
	public Connection getConnection() 
	{
		System.out.println("Mysql Connection");
		return null;
	}

}
