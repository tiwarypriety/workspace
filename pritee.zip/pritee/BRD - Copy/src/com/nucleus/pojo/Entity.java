package com.nucleus.pojo;

public class Entity {

	int code;
	String name;
	
}
