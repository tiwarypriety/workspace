package com.nucleus.execution;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

import com.nucleus.validation.Validation;
import com.nucleus.validation.ValidationI;

public class ReadFile {
	public static void main(String[] args) 
	{
	ValidationI v = new Validation();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the file location");
	String location=sc.next();
	System.out.println("Enter the file name");
	String fileName=sc.next();
	System.out.println("Enter the file extention");
	String fileExtention=sc.next();
	while(!(fileExtention.equals("txt")))
	{
		System.out.println("Enter valid file extention");
		fileExtention=sc.next();
	}
		try
		{
				BufferedReader br = new BufferedReader(new FileReader(location+":/"+fileName+"."+fileExtention));
				try
				{						
					String c;
					System.out.println("Enter your Choice(Rejection level)");
					System.out.println(" R  :  for Record level Rejection ");
					System.out.println(" F  :  for File level Rejection ");
					char d = sc.next().charAt(0);
					switch(d)
					{
							case 'R' :
									Rejection r1 = new Rejection(br,d);
									break;
							case 'F' :	
									Rejection r2 = new Rejection(br,d);
									break;
				}	
				}
				catch(Exception e)
				{			
					System.out.println(e);		
				}			
			
		
	}
	catch(Exception e)
	{
		System.out.println("File not found....!!");
	}
		
	}
}

