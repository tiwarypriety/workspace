package program8;

public class Vehicle
{
	int vehicleNo;
	String model;
	String manufacturer;
	String color;
	public Vehicle(int vehicleNo, String model, String manufacturer, String color) 
	{
		super();
		this.vehicleNo = vehicleNo;
		this.model = model;
		this.manufacturer = manufacturer;
		this.color = color;
	}
	public int getVehicleNo() {
		return vehicleNo;
	}
	public String getModel() {
		return model;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
}
