package program8;

public class Truck extends Vehicle
{
	int loadingCapacity;
public Truck(int vehicleNo, String model, String manufacturer, String color , int loadingCapacity)
{
		super(vehicleNo, model, manufacturer, color);
		this.loadingCapacity = loadingCapacity;
}
public int getLoadingCapacity() {
	return loadingCapacity;
}
public void setLoadingCapacity(int loadingCapacity) {
	this.loadingCapacity = loadingCapacity;
}
@Override
public String toString() {
	return "Truck [loadingCapacity=" + loadingCapacity + ", vehicleNo=" + vehicleNo + ", model=" + model
			+ ", manufacturer=" + manufacturer + ", color=" + color + "]";
}

}
