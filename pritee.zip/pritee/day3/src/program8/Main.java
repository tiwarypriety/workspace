package program8;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		int n;
		Truck t = new Truck(102,"TATA INDIGO","INDIA","RED",200);
		System.out.println("Enter your Choice: ");
		System.out.println("1: To change color ");
		System.out.println("2: To modify loading capacity");
		System.out.println("0: Exit");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();	
			switch(n){
			case 1 : 
				System.out.println("Enter the color to change");
				t.setColor(sc.next());
				System.out.println(t);
				break;
			case 2 :
				System.out.println("Enter the loading capacity to modify");
				t.setLoadingCapacity(sc.nextInt());
				System.out.println(t);
				break;
			case 0 :
				System.out.println("Exit");
				break;
		}
	}
}
