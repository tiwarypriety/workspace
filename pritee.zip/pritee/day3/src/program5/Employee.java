package program5;

public class Employee
{
	int empId;
	String name;
	String designation;
	int projectId;
	String phoneNumber;
	
	public Employee(int empId, String name, String designation, int projectId, String phoneNumber) 
	{
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		this.projectId = projectId;
		this.phoneNumber = phoneNumber;
	}
	public int getEmpId() {
		return empId;
	}
	public String getName() {
		return name;
	}
	public String getDesignation() {
		return designation;
	}
	public int getProjectId() {
		return projectId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
