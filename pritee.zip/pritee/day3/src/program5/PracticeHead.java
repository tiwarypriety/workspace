package program5;

public class PracticeHead extends Employee
{
	 String practiceName;
	int noOfCustomers;
	public PracticeHead(int empId, String name, String designation, int projectId, String phoneNumber,String practiceName,int noOfCustomers) 
	{
		super(empId, name, designation, projectId, phoneNumber);
		this.practiceName = practiceName;
		this.noOfCustomers = noOfCustomers;
		
	}
	public String getPracticeName() {
		return practiceName;
	}
	public int getNoOfCustomers() {
		return noOfCustomers;
	}

	public void setNoOfCustomers(int noofCustomers) {
		this.noOfCustomers = noofCustomers;
	}
	@Override
	public String toString()
	{
		return "PracticeHead [practiceName=" + practiceName + ", noofCustomers=" + noOfCustomers + ", empId=" + empId
				+ ", name=" + name + ", designation=" + designation + ", projectId=" + projectId + ", phoneNumber="
				+ phoneNumber + "]";
	}

}
