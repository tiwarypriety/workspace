package program5;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		PracticeHead p = new PracticeHead(101,"john","trainee",202,"7877877787","daniel",5);
		int n;
		System.out.println("Enter your Choice: ");
		System.out.println("1: To modify Number of customers ");
		System.out.println("2: To modify PhoneNumber");
		System.out.println("0: Exit");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		
			switch(n)
			{
			case 1 : 
				System.out.println("Enter the Number of customers to modify");
				p.setNoOfCustomers(sc.nextInt());
				System.out.println(p);
				break;
			case 2 :
				System.out.println("Enter the Number to modify");
				p.setPhoneNumber(sc.next());
				System.out.println(p);
				break;
			case 0 :
				System.out.println("Exit");
				break;
			}
	}
}
