package program7;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		int n;
		Periodical p = new Periodical(101,"Java","Gosling",400,"weekly");
		System.out.println(p);
		System.out.println("Enter your Choice: ");
		System.out.println("1: To modify Price ");
		System.out.println("2: To modify Period");
		System.out.println("0: Exit");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		
			switch(n)
			{
			case 1 : 
				System.out.println("Enter the Price to modify");
				p.setPrice(sc.nextDouble());
				System.out.println(p);
				break;
			case 2 :
				System.out.println("Enter the Period to modify");
				p.setPeriod(sc.next());
				System.out.println(p);
				break;
			case 0 :
				System.out.println("Exit");
				break;
			}
	}
}

