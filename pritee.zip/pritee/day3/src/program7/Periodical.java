package program7;

public class Periodical extends Book
{
	String period;
public Periodical(int bookId, String title, String author, double price,String period) 
{
		super(bookId, title, author, price);
		this.period = period;
}
public String getPeriod() {
	return period;
}

public void setPeriod(String period) {
	this.period = period;
}
@Override
public String toString() {
	return "Periodical [period=" + period + ", bookId=" + bookId + ", title=" + title + ", author=" + author
			+ ", price=" + price + "]";
}

}
