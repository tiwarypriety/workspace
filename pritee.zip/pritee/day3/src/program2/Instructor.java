package program2;

public class Instructor extends Person{
    
  private double salary;
  Instructor(String name, int year, double salary) {
  super(name, year);
  this.salary = salary;
  }
    public double getSalary() {
        return salary;
    }
	@Override
	public String toString() {
		return "Instructor [salary=" + salary + "]";
	}
    
}


