package program2;

	public class Student extends Person{
	    
	    private String major;
	  Student(String name, int year, String major) {
	    super(name, year);
	    this.major = major;
	  }
	  void display(){
	      System.out.println(getName()+" "+getYear()+" "+getMajor());
	  }

	    public String getMajor() {
	        return major;
	    }
		@Override
		public String toString() {
			return "Student [major=" + major + "]";
		}
	}

