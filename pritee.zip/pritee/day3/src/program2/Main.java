package program2;

public class Main {

	public static void main(String[] args) 
	{
		
		Person p1 = new Person("amay",1998);
		Person p2 = new Instructor("rahul",1994,3400);
		Person p3= new Student("jinny",2011,"MCA");
		Instructor a = new Instructor("John",1990,12000);
		Student s = new Student("Amit",1991,"BE");
		System.out.println(a);
		System.out.println(s);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
	}

}
