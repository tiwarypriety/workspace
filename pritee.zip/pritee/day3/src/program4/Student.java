package program4;

public class Student 
{
	int studentId;
	String name;
	int courseId; 
	String sex;
	String phoneNumber;
	public Student(int studentId, String name, int courseId, String sex, String phoneNumber) 
	{
		super();
		this.studentId = studentId;
		this.name = name;
		this.courseId = courseId;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
	}
	public int getStudentId() {
		return studentId;
	}
	public String getName() {
		return name;
	}
	public int getCourseId() {
		return courseId;
	}
	public String getSex() {
		return sex;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	    
}
