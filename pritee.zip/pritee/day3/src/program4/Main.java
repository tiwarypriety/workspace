package program4;

import java.util.Scanner;

public class Main 
{
  
    public static void main(String a[])
    {
    	int n;
    	Hosteller h = new Hosteller(102, "amit",201,"male","77878675","mohini",400);
    	System.out.println("Enter your Choice: ");
    	System.out.println("1: To modify Room Number ");
    	System.out.println("2: To modify Phone Number");
    	System.out.println("0: Exit");
    	Scanner sc = new Scanner(System.in);
    	n = sc.nextInt();
    	
    		switch(n)
    		{
    		case 1 : 
    			System.out.println("Enter the Room Number to Modify");
    			h.setRoomNumber(sc.nextInt());			
    			System.out.println(h);
    			break;
    		case 2 :
    			System.out.println("Enter the Phone Number to modify");
    			h.setPhoneNumber(sc.next());
    			System.out.println(h);
    			break;
    		case 0 :
    			System.out.println("Exit");
    			break;
    		}    	
    }
}