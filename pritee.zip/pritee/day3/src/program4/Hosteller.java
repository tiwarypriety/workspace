package program4;

public class Hosteller extends Student
{

	String hostelName;
	int roomNumber;
	public Hosteller(int studentId, String name, int courseId, String sex, String phoneNumber, String hostelName,
			int roomNumber) 
	{
		super(studentId, name, courseId, sex, phoneNumber);
		this.hostelName = hostelName;
		this.roomNumber = roomNumber;
	}
	public String getHostelName() {
		return hostelName;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public void setRoomNumber(int hostelNumber) {
		this.roomNumber = roomNumber;
	}
	@Override
	public String toString() {
		return "Hosteller [hostelName=" + hostelName + ", roomNumber=" + roomNumber + ", studentId=" + studentId
				+ ", name=" + name + ", courseId=" + courseId + ", sex=" + sex + ", phoneNumber=" + phoneNumber + "]";
	}
	
}

