package program6;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args)
	{
	int n;
	ElectricalProduct e = new ElectricalProduct(101,"john",201,60,40,100);
	//System.out.println(e);
	System.out.println("Enter your Choice: ");
	System.out.println("1: To modify Price ");
	System.out.println("2: To modify Wattage");
	System.out.println("0: Exit");
	Scanner sc = new Scanner(System.in);
	n = sc.nextInt();
	
		switch(n)
		{
		case 1 : 
			System.out.println("Enter the Price to modify");
			e.setUnitPrice(sc.nextDouble());			
			System.out.println(e);
			break;
		case 2 :
			System.out.println("Enter the Wattage to modify");
			e.setWattage(sc.nextDouble());
			System.out.println(e);
			break;
		case 0 :
			System.out.println("Exit");
			break;
		}
	
   }

}
