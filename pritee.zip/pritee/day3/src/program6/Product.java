package program6;

public class Product
{
	int productId;
	String name;
	int categoryId;
	public Product(int productId, String name, int categoryId, double unitPrice) 
	{
		this.productId = productId;
		this.name = name;
		this.categoryId = categoryId;
		this.unitPrice = unitPrice;
	}
	public int getProductId() {
		return productId;
	}
	public String getName() {
		return name;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice){
		this.unitPrice = unitPrice;
	}
	double unitPrice;	
}
