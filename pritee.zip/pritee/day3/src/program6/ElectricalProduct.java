package program6;

public class ElectricalProduct extends Product
{
int voltageRange;
double wattage;
	public ElectricalProduct(int productId, String name, int categoryId, double unitPrice,int voltageRange, double wattage) 
	{
		super(productId,name,categoryId,unitPrice);
		this.voltageRange = voltageRange;
		this.wattage = wattage;
	
	}
public int getVoltageRange() {
	return voltageRange;
}
public double getWattage() {
	return wattage;
}
public void setWattage(double wattage) {
	this.wattage = wattage;
}
@Override
public String toString() {
	return "ElectricalProduct [productId=" + productId + ", name=" + name + ", categoryId=" + categoryId + ", unitPrice="
				+ unitPrice + "voltageRange=" + voltageRange + ", wattage=" + wattage + "]";
}
}
