package program3;

public class Main {
    public static void main(String args[])
  { 
      Executive e=new Executive("JOHN",12000,"Testing");
      System.out.println(e);
  }
}
