package program3;

public class Executive extends Manager{
    Executive(String name,  double salary, String dept)
    {
     super(name, salary,dept);
    }
    public  String toString()
    {      
        return "Executive NAME IS: "+  getName() + " \nSALARY IS: "+  getSalary()+ "\nDEPARTMENT IS: " + dept +"";
  
}
}