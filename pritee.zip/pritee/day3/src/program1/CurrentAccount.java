package program1;

public class CurrentAccount extends Bank
{
	 final double minbalance=500;
	 	    double accountBalance = super.getAccountBalance();
	  //  System.out.println( accountBalance );

	        double withdraw(double amount)
	        {
			if(super.getAccountBalance()>amount)
			{
			double c =super.getAccountBalance()-amount;
			      if(c<minbalance)
	                      {
	                          System.out.println("Account balance is less than minimum balance");
	                          double m= c-100;
	                         super.setAccountBalance(m);
	                         System.out.println("balance is "+ m);
	                      }
	                      else
	                      {
	                        System.out.println("balance is" + c)  ;
	                      super.setAccountBalance(c);}
	                      }
			else
			{
				System.out.println("Sorry!! Your account has less balance");
			}
			return accountBalance;
			}
	    
	    public void display()
	    {
		double accountBalance =super.getAccountBalance();
		System.out.println("Your account balance is"+ accountBalance);
		                                                 
	}
}
