package program1;

import java.util.Random;

public class Bank 
{
	private String customerName;
	private String accountNo;
	private String type_of_account;
	private double accountBalance;
	
	public String getCustomerName() 
	{
		return customerName;
	}

	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}

	public String getAccountNo()
	{
		return accountNo;
	}

	public void setAccountNo(String accountNo)
	{
		this.accountNo = accountNo;
	}

	public String getType_of_account()
	{
		return type_of_account;
	}
	public void setType_of_account(String type_of_account)
	{
		this.type_of_account = type_of_account;
	}

	public double getAccountBalance() 
	{
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance)
	{
		this.accountBalance = accountBalance;
	}
    void init(String name,String type_of_account, double initialBalance)
         {     
            setCustomerName(name);
            setAccountBalance(initialBalance);
            setType_of_account(type_of_account);	
          }
	void deposit(double amount)
	{
		accountBalance+=amount;
		System.out.println("Your amount has been deposited");
	}

       void random1()
     { 
    	   Random r=new Random();
    	   accountNo = 10000+r.nextInt(89999)+"";
      }
}