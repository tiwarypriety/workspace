package program1;

public class SavingAccount extends Bank{
 final double interest = 5;
 private double max_limit;
 private double minBalance = 500;
SavingAccount(){};
	public SavingAccount(String memberName, double accountBalance) {
	super();
	
	this.minBalance = minBalance;
	this.accountBalance = accountBalance;
}


	private double accountBalance = getAccountBalance();

	double withdraw(double amount){
			if(amount<getAccountBalance()){
	          setAccountBalance(getAccountBalance()-amount);
			}
			else{
				System.out.println("Sorry!! Your amount is Exceeding the current amount!!");
			}
			return getAccountBalance();}


	public void display(){
		double accountBalance = getAccountBalance();
//accountBalance = accountBalance+(accountBalance*5)/100;
		System.out.println(accountBalance);
	}
}
