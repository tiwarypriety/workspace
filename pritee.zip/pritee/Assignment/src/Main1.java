
public class Main1 {

	public static void main(String[] args) {
		Movie m1 = new Movie("john","***");
		Movie m2 = new Movie("King","*****");
		Movie m3 = new Movie("amit","******");
		Movie m4 = new Movie("xyz","**");
		Movie m5 = new Movie("rohan","*****");
		
	}

}
