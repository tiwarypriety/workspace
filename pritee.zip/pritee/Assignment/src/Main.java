
public class Main 
{

	public static void main(String[] args)
	{
	Ticket t = Ticket.createTicket("xyz", 340);
		t.show();
     }

}
