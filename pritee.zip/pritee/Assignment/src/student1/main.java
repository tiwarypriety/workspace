package student1;

public class main 
{

	public static void main(String[] args)
	{
		Exam e = new Exam(001,"amit",100,101,"btech");
		Student s = new Student(002, "amay", 505);
		Course c = new Course(003, "john", 333, 202,"MCA");
		
		e.show();
		c.show();	
		s.show();								
	}

}
