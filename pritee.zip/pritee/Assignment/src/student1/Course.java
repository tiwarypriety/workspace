package student1;

public class Course extends Student
{
  int cId;
  String cName;
	
  public Course(int rollNo, String name, int marks, int cId, String cName) 
    {
		
	  super(rollNo, name, marks);
		this.cId = cId;
		this.cName = cName;
		
	}
	
    void show()
    {
		System.out.println(rollNo+ "  "+name+ " "+marks+" "+cId+" "+cName);
	}

}
