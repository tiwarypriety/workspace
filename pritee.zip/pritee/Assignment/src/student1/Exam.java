package student1;
public class Exam extends Course
{

	public Exam(int rollNo, String name, int marks, int cId, String cname)
	{
		super(rollNo, name, marks, cId, cname);
		
	}


}
