package student1;

public class Student 
{

	int rollNo;
	String name;
	int marks;
	
	public Student(int rollNo, String name, int marks)
	{
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}
	void show()
	{
		System.out.println(rollNo+ " "+name+ " "+marks);
	}
		
}
