package person;

public class Person {
String name;

public Person(String name) {
	super();
	this.name = name;
}
void show(){
	
	System.out.println();
}
}
