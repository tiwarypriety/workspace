package person;

public class Contact extends Person
{
	String  number;
	String std;
	public Contact(String name, String number, String std) {
		super(name);
		this.number = number;
		this.std = std;
	}
	
	
}
