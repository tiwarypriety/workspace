package person;



public class Main {

	public static void main(String[] args)
	{
		Contact[] contact = new Contact[2];
		contact[0] = new Contact("john","78799","98");
		
	}

	}


