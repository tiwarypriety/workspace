
public class Ticket

{
	  static int counter = 0;
	  static String name;
	  static int ticketId;	
	
	  Ticket(String name, int ticketId)
	  {
		this.name = name ;
		this.ticketId = ticketId;

	  }
	  
	  static Ticket createTicket(String name, int id){
		  if(++counter<=10){
			  return new Ticket("amit",3461);
		  }
		  return null;
	  }

	     void show()
	     {
	     	     
		      System.out.println("Ticket ID ="+ticketId+"  "+"Name = "+name);
		      System.out.println("Ticket left ="+(10-counter));
		      
		  }

 }
