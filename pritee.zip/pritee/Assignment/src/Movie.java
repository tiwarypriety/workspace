
public class Movie {

	String name;
	String rating;
	
	Movie(String name)
	{
		this.name = name;
	}
	
	Movie(String name , String rating)
	{
		int r = rating.length();
		if(calRating(r)==true)
		{		
		System.out.println("Name= "+ name+"   "+"Rating ="+rating);
		}
		else
		{
			System.out.println("Rating not equal to 5");
		}
	}
	boolean calRating(int r)
	{
		if(r==5)
	return true;
		return false;
		
	}
}
