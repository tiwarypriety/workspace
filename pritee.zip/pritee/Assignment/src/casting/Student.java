package casting;

class Student 
{ 
    public void callme()
    {
        System.out.println("callme of Student");
    }
}
