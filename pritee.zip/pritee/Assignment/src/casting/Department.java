package casting;

	class Department extends Student 
	{ 
	    public void callme()
	    {
	        System.out.println("callme of Department");
	    }

	    public void callme2()
	    {
	        System.out.println("callme2 of Department");
	    }
	}


