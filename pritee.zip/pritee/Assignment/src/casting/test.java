package casting;

public interface test {
  int i =5;
}
