package casting;

public class Main {

	public static void main(String[] args) {
		   Department d = new Department();
		   d.callme();
		   Student s = new Department();
		   s.callme();
		   Student s1 = (Student)d;
		   s1.callme();
		   Student s2 = new Student();
		   s2.callme();
	}

}
