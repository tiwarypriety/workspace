package practice;

public class Demo {
	
	Demo()
	{
		this(6);
		System.out.println("Default");
	}
	
	Demo(int num){
		this(5,6);
		System.out.println(num);
	}
	Demo(int num1, int num2)
	{
		System.out.println(num1*num2);
	}
	public static void main(String[] args) {
	 new Demo();
	}

}
