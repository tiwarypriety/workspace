package practice;

import java.util.Scanner;

public class StudentGrades {

	public static void main(String[] args)
	{
	int employee;
	System.out.println("Enter number of students");
	Scanner sc = new Scanner(System.in);
	employee = sc.nextInt();
	int a[] = new int [employee];
	
	for(int i= 0;i<employee;i++){
		System.out.println("Enter Grades for Student "+(i+1));
		int x = sc.nextInt();
		if(x>100)
		{
			System.out.println("Invalid grade , try Again...");
		     i--;
		}
		else
			a[i] = x;		
	}
	StudentGrades s = new StudentGrades();
	float avg = s.average(a,employee);
	System.out.println("Average = "+avg);
	
	}
	float average(int a[], int n){
    int sum =0;
     for(int i =0;i<n;i++){
			sum = sum + a[i];
		}
    float average = sum/n;
		return average;
	}
	
	}
