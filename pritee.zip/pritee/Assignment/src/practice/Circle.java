package practice;

public class Circle {

private	double radius = 1.0;
public	String color  = "red";

double getRadius() {
	return radius;
	
}

double getArea(){
	return 3.14*radius*radius;
}
	
	Circle(){
		
	}
	Circle(double r){
		
	}
	
	public static void main(String[] args) {
		
new Circle();
	}

}
