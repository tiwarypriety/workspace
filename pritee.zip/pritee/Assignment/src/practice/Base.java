package practice;


class Base{
	String name;
	Base()
	{
		this("New York"); 
		System.out.println( "no arguments");
	}
	public Base(String name) {
		 this("hell0",2);
		this.name = name;
		System.out.println("one Arguments");
   
}
	Base(String name , int a){
		System.out.println("Two Arguments");
	}	
	
	public static void main(String a[])
	{
	new Base();	
	}
}





