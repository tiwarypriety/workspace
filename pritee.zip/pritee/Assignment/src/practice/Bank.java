package practice;

import java.util.Random;

 class Account{
    String name;
	double balance;
	
	double deposit(){
		return 1;
	}
	Random rand = new Random();
	String accountNumber ="" + rand.nextInt(10) + rand.nextInt(10)+ rand.nextInt(10)+
	rand.nextInt(10)+ rand.nextInt(10);
	
}

class SavingsAccount extends Account{
	int interest = 5, max_withdraw_limit=1000;
	double getBalance(){
		balance += balance*(interest/100);
		return balance;
	}
	double withdraw(){
		double withdrawAmount=100;
		if(withdrawAmount<max_withdraw_limit)
	return withdrawAmount;
		return withdrawAmount;
	}
	
	
}



















public class Bank {

	public static void main(String[] args) {
	
	}

}
