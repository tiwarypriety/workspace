
public class Test {

	public static void main(String[] args) {
		Department dep=new Department(10,"Accounts");
		dep.show();
		Department dep2=new Department(20);
		dep2.show();
		Department dep3=new Department();
		dep3.show();

	}

}
