package file;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Main 
{

	public static void main(String[] args) throws Exception 
	{
		Employee e = new Employee();
		Validation v =new Validation();
		
			boolean email = false,address = false,id = false;
			
			
			BufferedReader br = new BufferedReader(new FileReader("d:/EmployeeData.txt"));
			String x;
			while((x = br.readLine())!=null)
			{
				String words[] = x.split("~",-1);											
			address = v.checkAddress(e.getAddress1());	
			
			email =	v.checkEmailFormat(e.getEmail());
			
      		id = v.checkEmpId(e.id);
      		System.out.println(address);
      		System.out.println(id);
      		System.out.println(email);
				if(address&&email&&id)
				{
					PrintWriter out = new PrintWriter("d:/new1EmployeeData.txt");
					
					 for(int i = 0;i<words.length;i++)
					 {						 
						 out.write(words[i]);
						 out.write(" ");						
					 }
				
					out.flush();
				}
			}			
	}
}



