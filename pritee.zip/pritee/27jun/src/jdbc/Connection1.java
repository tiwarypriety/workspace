package jdbc;

import java.sql.Connection;

public interface Connection1 {

	public Connection getConnection();
	
}
