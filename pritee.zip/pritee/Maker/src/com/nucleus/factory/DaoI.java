package com.nucleus.factory;

public interface DaoI {

	
	public DAOFactory getFactory();
}
