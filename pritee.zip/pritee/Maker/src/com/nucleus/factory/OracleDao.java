package com.nucleus.factory;

public class OracleDao implements DaoI {

	@Override
	public DAOFactory getFactory() {		
		return ;
	}

	
}
