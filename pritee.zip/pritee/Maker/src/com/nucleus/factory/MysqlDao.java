package com.nucleus.factory;

public class MysqlDao implements DaoI {

	@Override
	public DAOFactory getFactory() {
		return null;
	}

}
