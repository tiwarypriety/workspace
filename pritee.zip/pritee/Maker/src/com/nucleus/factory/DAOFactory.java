package com.nucleus.factory;
public class DAOFactory 
{
	

	public static DaoI getDaoFactory(String str) {
	
		if(str.equalsIgnoreCase("oracle"))
		{
			return new OracleDao();
		}
		if(str.equalsIgnoreCase("mysql"))
		{
			return new MysqlDao();
		}
		else
		{
			System.out.println("Wrong choice..!!");
			return  null;
		}	
	}
}
