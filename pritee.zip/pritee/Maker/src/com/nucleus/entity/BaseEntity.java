package com.nucleus.entity;

public class BaseEntity {

	public String name;
	
}
