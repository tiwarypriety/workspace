package com.nucleus.connection;

import java.sql.Connection;

public interface ConnectionI 
{
	public Connection getConnection();

}
