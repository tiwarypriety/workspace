package com.nucleus.connection;

import com.nucleus.connection.ConnectionI;
import com.nucleus.connection.OracleConnection;

public class ConnectionFactory 
{
	public static ConnectionI getConnectionMethod(String str)
	{
		if(str.equalsIgnoreCase("oracle"))
		{
			return new OracleConnection();
		}
		else if(str.equalsIgnoreCase("mysql"))
		{
			return new MysqlConnection();
		}
		else
		{

			System.out.println("Wrong choice..!!");
			return  null;
		}
	}
}
