package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.dao.CustomerDAOI;
import com.nucleus.entity.Customer;
import com.nucleus.service.CustomerService;
import com.nucleus.service.CustomerServiceI;
import com.nucleus.service.UserService;
import com.nucleus.service.UserServiceI;
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UserServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session = request.getSession(false);
		PrintWriter p = response.getWriter();
		if (action.equals("Logout"))
		{
					if(session!=null)
					{
						RequestDispatcher  rd = request.getRequestDispatcher("Logout.jsp");
						rd.include(request, response);
					}
					else
					{
						RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
						rd.include(request, response);
					}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
			HttpSession session = request.getSession(false);
			String action = request.getParameter("action");	
		 
		
			UserServiceI s = new UserService();
			if(action.equals("login"))
			{
						String user = request.getParameter("user");
						String password = request.getParameter("pass");
						boolean check = s.login(user, password);
						if(check)
						{	
					
									String role = s.getRole(user);
									if(role.equalsIgnoreCase("Maker"))
									{
											session = request.getSession();
											session.setAttribute("username", user);
											RequestDispatcher  rd = request.getRequestDispatcher("User.html");
											rd.forward(request, response);
									}
									else 
									{
											RequestDispatcher  rd = request.getRequestDispatcher("Checker.jsp");
											rd.forward(request, response);
									}
						}
						else
						{
							PrintWriter p = response.getWriter();
							p.print("Invalid Credential");
							RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
						}
			}
		if (action.equals("Logout"))
		{
						if(session!=null)
						{
										try
										{
												session.invalidate();
												PrintWriter p = response.getWriter();
												
												p.println("logged out Successully!!");
									
												RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
												rd.include(request, response);
										}
										catch(Exception e)
										{
												RequestDispatcher  rd = request.getRequestDispatcher("ErrorPage.jsp");
												rd.include(request, response);
										}
						}
						else
						{
							RequestDispatcher  rd = request.getRequestDispatcher("Login.jsp");
							rd.forward(request, response);				
						}	
		}		
	}
}
