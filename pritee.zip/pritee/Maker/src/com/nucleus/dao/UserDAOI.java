package com.nucleus.dao;

public interface UserDAOI
{
		public boolean login(String u ,String p);
		public String getRole(String user);
}
