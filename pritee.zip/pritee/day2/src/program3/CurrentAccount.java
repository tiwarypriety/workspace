package program3;

public class CurrentAccount extends Account{
	int tradeLicenseNumber;
	CurrentAccount(){}
	public CurrentAccount(String memberName, double accountBalance) {
		super(memberName, accountBalance);
			}
	
	public void withdraw(double amount){

		if(amount<getBalance())
		{
			setAccountBalance(getBalance()-amount);
			System.out.println("Money Withdrawn");
	}else{
		System.out.println("Insuficient Balance");
	}
		
}
}
