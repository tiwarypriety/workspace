package program3;

public class SavingsAccount extends Account
{
	SavingsAccount(){}
	final double interest = 5;
	 double max_limit ;
	private double minBalance = 500;
public SavingsAccount(String memberName, double accountBalance) {
		super(memberName, accountBalance);
	}
void maxLimit(double max_limit){
	System.out.println(max_limit);
	this.max_limit = max_limit;
	
}
void  withdraw(double amount)
{
	if(amount<getBalance()){
		
if(amount<max_limit)
	{
		setAccountBalance(getBalance()-amount);
		System.out.println("Money Withdrawn");
	}else
	{
		System.out.println("Maximum limit Exceeds");
	}
}else
	System.out.println("InSuficient Balance");
}
}
