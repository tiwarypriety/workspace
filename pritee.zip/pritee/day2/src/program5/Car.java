package program5;

public class Car {
   private int noOfDoor;
   
    
    public Car(int noOfDoor) {
	super();
	this.noOfDoor = noOfDoor;
}

	public int getNoOfDoor() {
        return noOfDoor;
    }

	@Override
	public String toString() {
		return "Car [noOfDoor=" + noOfDoor + "]";
	}
  
 }

