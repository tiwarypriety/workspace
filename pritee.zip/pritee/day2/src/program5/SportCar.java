package program5;

public class SportCar extends Car{

	public SportCar(int noOfDoor) {
		super(noOfDoor);

	}

	@Override
	public String toString() {
		return "SportCar [getNoOfDoor()=" + getNoOfDoor() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
