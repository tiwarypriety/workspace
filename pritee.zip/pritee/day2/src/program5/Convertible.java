package program5;

public class Convertible extends Car{
    boolean isHoodOpen;

	public Convertible(int noOfDoor, boolean isHoodOpen) {
		super(noOfDoor);
		this.isHoodOpen = isHoodOpen;
	}

	public boolean isHoodOpen() {
		return isHoodOpen;
	}

	public void setHoodOpen(boolean isHoodOpen) {
		this.isHoodOpen = isHoodOpen;
	}

	@Override
	public String toString() {
		return "Convertible [isHoodOpen=" + isHoodOpen + ", getNoOfDoor()=" + getNoOfDoor() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

    
    
}

