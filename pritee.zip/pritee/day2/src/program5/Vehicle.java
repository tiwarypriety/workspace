package program5;

public class Vehicle extends Car{
    int noOfWheel;
    int noOfPassenger;
    int model;
    String make;


public Vehicle(int noOfDoor, int noOfWheel, int noOfPassenger, int model, String make) {
		super(noOfDoor);
		this.noOfWheel = noOfWheel;
		this.noOfPassenger = noOfPassenger;
		this.model = model;
		this.make = make;
	}


@Override
public String toString() {
	return "Vehicle [noOfWheel=" + noOfWheel + ", noOfPassenger=" + noOfPassenger + ", model=" + model + ", make="
			+ make + ", getNoOfDoor()=" + getNoOfDoor() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
			+ ", toString()=" + super.toString() + "]";
}



}


