package program5;

import java.util.Scanner;

public class Main {
    public static void main(String a[])
    {
    	int x;
        Scanner sc = new Scanner(System.in);
        do{
        System.out.println("Enter Your Choice:");
        System.out.println("1 : To create Vehicle object");
        System.out.println("2 : To create Car object");
        System.out.println("3 : To create Convertible object");
        System.out.println("4 : To create SportCar object");
        System.out.println("0 : Exit");
         x= sc.nextInt();
        	switch(x)
        	{
        		case 1 : 
                       Vehicle v = new Vehicle(6,5,10,2,"China");
                       System.out.println(v);
                       break;
        		case 2 : 
                       Car c = new Car(2);
                       System.out.println(c);
                       break;
        		case 3 : 
                    Convertible con = new Convertible(3,true);
                      System.out.println(con);
                       break;
        		case 4 : 
                     SportCar s = new SportCar(2);
                     System.out.println(s);
                       break;
       	case 0 : 
            	 	 System.out.println("Exit");
            	 	   break;
        	}
        }while(x!=0);
   }
}

