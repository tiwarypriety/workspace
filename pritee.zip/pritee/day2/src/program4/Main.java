package program4;

import java.util.Scanner;

public class Main {
    public static void main(String a[]){
        Student s = null;
        int x;
      Scanner sc  =new Scanner(System.in);
        System.out.println("Enter Choice : ");
        System.out.println("1 : To Create Student Object");
        System.out.println("2 : To Display");
        do{
        x = sc.nextInt();
        switch(x){
            case 1 : 
                    System.out.println("Enter Id");
                   String id  = sc.next();
                    System.out.println("Enter Name");
                   String name = sc.next();
                    System.out.println("Enter Grade");
                   double grade = sc.nextDouble();
                    s = new Student(name, id, grade);
                    System.out.println("Object Created");
                    break;
            case 2 : 
                   if(s == null)
                   {
                       System.out.println("Please Create an Object!!");
                   }
                   else{
                       int year = sc.nextInt();
                       s.display();                      
                          }
                   break;
    }
        }while(x!=1||x!=2);
        
   }  
}

