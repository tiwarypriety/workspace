
package program4n;


public class Student {
    String name;
	String id;
	String grade;
	Student(String name, String id, String grade)
	{
		this.name=name;
		this.id=id;
		this.grade=grade;
		System.out.println("Object created successfully!");
	}
	Student(String name, String id)
	{
		this.name=name;
		this.id=id;
		
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + ", grade=" + grade + "]";
	}
	Student(String id)
	{
		this.id=id;
	}
	
	void display(String year)
	{
		System.out.println("Name: "+name);
		System.out.println("Id: "+id);
		System.out.println("Grade: "+grade);
		System.out.println("Year: "+year);
	}
    
}
