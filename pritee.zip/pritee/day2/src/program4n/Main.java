
package program4n;
import java.util.Scanner;

public class Main
{
   public static void main(String[] args) {
       Student student=null;
		int flag=0;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("Press 1 to create Student object");
			System.out.println("Press 2 to display student info");
			int i=sc.nextInt();
			
			if(i==1)
			{
				System.out.println("Enter Name of Student");
				sc.nextLine();
				String name=sc.nextLine();				
				System.out.println("Enter Id of Student");
				String id=sc.nextLine();
				System.out.println("Enter Grade of student");
				String grade=sc.nextLine();
				if(grade==null)
					student=new Student(name,id);
				else if(grade==null && name==null)
					student=new Student(id);
				else
					student=new Student(name,id,grade);
				System.out.println(student);;
			}
			else if (i==2)
			{
				System.out.println("Enter current year of student");
	
				String year=sc.next();
				if(year==null)
					System.out.println(student);
				else
					student.display(year);
			}
		}while(flag==0);
	}

}

    
    

