package program2;

public class BookStore 
{
Book[] book;

public BookStore()
{
	super();
	book = new Book[10];
	
}
void init()
{
	
		book[0] = new Book("Java1","James Gosling","ISBN101",10);
		book[1] = new Book("Java2","James Gosling","ISBN102",20);
		book[2] = new Book("Java3","James Gosling","ISBN103",30);
		book[3] = new Book("Java4","James Gosling","ISBN104",50);
		book[4] = new Book("Java5","James Gosling","ISBN105",20);
		book[5] = new Book("Java6","James Gosling","ISBN106",40);
		book[6] = new Book("Java7","James Gosling","ISBN107",10);
		book[7] = new Book("Java8","James Gosling","ISBN108",15);
		book[8] = new Book("Java9","James Gosling","ISBN109",20);
		book[9] = new Book("Java0","James Gosling","ISBN110",50);
}
public void sell(String bookTitle ,int noOfCopies)
{
	boolean bookFound = true;
	for(int i=0;i<book.length;i++)
	{
		if(book[i].getBookTitle().equals(bookTitle))
		{
			if(book[i].getNumOfCopies()>=noOfCopies)
			{
				book[i].setNumOfCopies(book[i].getNumOfCopies()-noOfCopies);
				bookFound = true;

			}
			else
			{
				bookFound=false;
			}

			if(bookFound)
			{
				System.out.println(book[i].getBookTitle()+" is SOlD "+book[i].getNumOfCopies()+" book left ");
			}
			else
			{
				System.out.println("Not Available..");
			}
			break;
		}
	}
	
}
public void order(String isbn, int noOfCopies)
{
boolean order = false;
int i;
for(i = 0;i<book.length;i++)
   {
		if(book[i].getISBN().equals(isbn))
		{
			book[i].setNumOfCopies(book[i].getNumOfCopies()+noOfCopies);
			order= true;
		}
	if(order)
		{
			System.out.println(book[i].getBookTitle()+"  Book Added");
			System.out.println("Number of Copies Available ="+book[i].getNumOfCopies());
		}
	else{
		addNewBook(i,isbn,noOfCopies);
			System.out.println("new Book Added");	
    	}
	break;
   }

}

	public void addNewBook(int i,String isbn,int noOfCopies)
	{
		System.out.println(i);
	book[++i].setISBN(isbn);
	book[i].setNumOfCopies(book[i].getNumOfCopies()+noOfCopies);
	}
void display()
    {
	for(int i=0;i<book.length;i++){
		book[i].display();
	}
  }
}
