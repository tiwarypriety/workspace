package com.nucleus;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Test 
{
@RequestMapping(value = "login" ,method = RequestMethod.POST)
public ModelAndView show(@ModelAttribute("customer") Customer customer )
{
	
	return new ModelAndView("ViewAllDetails","customer",customer);
	
}

@RequestMapping(value ="show", method = RequestMethod.POST)
public String show()
{
	
	return "Login";
}
/*@RequestMapping(value = "/display/{1}")
public String show1(@PathVariable(value ="1") int a )
{
	System.out.println(a);
	return "Login";
}*/


@RequestMapping(value = "/delete/{1}")
public String show1(@PathVariable(value ="1") int a )
{
	System.out.println(a);
	return "Login";
}

@RequestMapping(value = "/login/{a}")
public String show11(@PathVariable(value ="a") int abc)
{
	System.out.println(abc);
	return "Login";
}

}