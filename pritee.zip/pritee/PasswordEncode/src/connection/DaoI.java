package connection;

public interface DaoI {

	
	public DAOFactory getFactory();
}
