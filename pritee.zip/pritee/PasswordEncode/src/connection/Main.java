package connection;
public class Main {

	public static void main(String[] args) {
		ConnectionI c = ConnectionFactory.getConnectionMethod("oracle");
		c.getConnection();	
		DaoI d =DAOFactory.getDaoFactory("oracle");
		d.getFactory();
			
	}

}
