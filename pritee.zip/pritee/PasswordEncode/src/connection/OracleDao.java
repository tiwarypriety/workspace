package connection;

public class OracleDao implements DaoI {

	@Override
	public DAOFactory getFactory() {		
		return null;
	}

	
}
