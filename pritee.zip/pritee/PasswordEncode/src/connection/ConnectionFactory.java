package connection;

import connection.ConnectionI;
import connection.OracleConnection;

public class ConnectionFactory 
{
	public static ConnectionI getConnectionMethod(String str)
	{
		if(str.equalsIgnoreCase("oracle"))
		{
			return new OracleConnection();
		}
		else if(str.equalsIgnoreCase("mysql"))
		{
			return new MysqlConnection();
		}
		else
		{

			System.out.println("Wrong choice..!!");
			return  null;
		}
	}
}
