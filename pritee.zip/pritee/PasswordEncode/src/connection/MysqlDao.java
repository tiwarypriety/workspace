package connection;
public class MysqlDao implements DaoI {

	@Override
	public DAOFactory getFactory() {
		return null;
	}

}
