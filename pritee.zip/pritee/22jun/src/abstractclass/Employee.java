package abstractclass;

public abstract class Employee  extends Person
{
int eId;
String eName;

abstract void  show();

void display()
{
	System.out.println("Employee");
}
}
