package abstractclass;

public class Manager extends Employee{

	@Override
	void show() {
System.out.println( "Manager");
	}

	
	
	
}
