package abstractclass;

public abstract class Person 
{
String name;

abstract void show();

	void display(){
		System.out.println("Person");
	}
}
