package abstractclass;

public class Main {

	public static void main(String[] args) {
		Manager m = new Manager();
		m.show();
		m.display();
		
	}

}
