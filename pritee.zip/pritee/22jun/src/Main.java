
public class Main
{
	public static void main(String[] args)
	{
	DataType d = new DataType();
     d.checkDataType(true);
     }

}
