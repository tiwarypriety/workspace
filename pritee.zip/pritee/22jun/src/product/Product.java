package product;

public class Product {

	Product p = new Product();
	
	
}
