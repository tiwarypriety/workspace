
public class DataType
{
void checkDataType(Object ob)
{
	Class cls = ob.getClass();
	System.out.println(cls.getSimpleName());
	
}

	
}
