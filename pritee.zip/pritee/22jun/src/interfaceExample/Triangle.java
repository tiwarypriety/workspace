package interfaceExample;

public class Triangle implements Calculate{

	@Override
	public void calculate() {
		double res;
		res= (1/2)*Calculate.b*Calculate.h;
		System.out.println("Area of Trangle = "+res);
	}

}
