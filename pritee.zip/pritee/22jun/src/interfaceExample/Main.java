package interfaceExample;

public class Main {

	public static void main(String[] args) {
Circle c = new Circle();
c.calculate();
Rectangle r = new Rectangle();
r.calculate();
Triangle t = new Triangle();
t.calculate();
	}

}
