package interfaceExample;

public class Rectangle implements Calculate{

	@Override
	public void calculate() {
		double res;
	res = Calculate.l*Calculate.b;
	System.out.println("Area of Rectangle ="+res);
	}

}
