package interfaceExample;

public class Circle implements Calculate{

	@Override
	public void calculate() {
		double res;
		res =  2*3.14*(Calculate.b);
	System.out.println("Area of Circle = "+res);	
	}

	
}
