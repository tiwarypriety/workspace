package interfaceExample;

public interface Calculate {
double r=10; 
double b= 4;
double l =8;
int h = 6;

void calculate();
}
