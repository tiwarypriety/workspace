package POJO;

public class Main {

	public static void main(String[] args) {
		Employee e = new Employee(001,"john",12000.0,"Testing","01-01-2017");	
		System.out.println(e);
	}

}
