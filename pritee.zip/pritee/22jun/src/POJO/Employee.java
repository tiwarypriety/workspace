package POJO;

public class Employee {
private int eId;
private String eName;
private double salary;
private String department;
private String hire_date;

public Employee(int eId, String eName, double salary, String department, String hire_date) {
	super();
	this.eId = eId;
	this.eName = eName;
	this.salary = salary;
	this.department = department;
	this.hire_date = hire_date;
}
public int geteId() {
	return eId;
}
public String geteName() {
	return eName;
}
public double getSalary() {
	return salary;
}
public String getDepartment() {
	return department;
}
public String getHire_date() {
	return hire_date;
}
public void seteId(int eId) {
	this.eId = eId;
}
public void seteName(String eName) {
	this.eName = eName;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public void setDepartment(String department) {
	this.department = department;
}
public void setHire_date(String hire_date) {
	this.hire_date = hire_date;
}
@Override
public String toString() {
	return "Employee [eId=" + eId + ", eName=" + eName + ", salary=" + salary + ", department=" + department
			+ ", hire_date=" + hire_date + "]";
}
}
