package autoboxing;

public class AutoBoxing {

	public static void main (String[] args)
    { 
        Integer i = new Integer(5);
        int a = i;                                          //Autoboxoing
        System.out.println("Value of i " + i);
        System.out.println("Value of a " + a);
 
        
        
        
        Character letter = 'z';
        char c = letter;                                   // Unboxing
        System.out.println("Value of c " +c);
        System.out.println("Value of letter " + letter);
 
    }


}
